import './style.css'

const app = document.querySelector('#app')
app.innerHTML = `
  <main class="shell">
    <header class="topbar"><div class="mark">S</div><span>SKETCHFAB <b>WEB</b></span><span class="pill">MOBILE READY</span></header>
    <section class="hero">
      <p class="eyebrow">3D MODEL WORKSPACE</p>
      <h1>Explore your<br><span>3D world.</span></h1>
      <p class="intro">Paste a Sketchfab model link to preview it here. Use the model owner's official download option when downloads are enabled.</p>
      <form id="model-form" class="form">
        <label for="model-url">SKETCHFAB MODEL URL</label>
        <div class="input-row"><input id="model-url" type="url" placeholder="https://sketchfab.com/3d-models/..." autocomplete="url" required><button type="submit">Preview <span>↗</span></button></div>
        <p id="message" class="message" aria-live="polite">Paste a public model page URL to get started.</p>
      </form>
    </section>
    <section class="viewer-wrap">
      <div class="viewer-head"><span>MODEL PREVIEW</span><span id="viewer-state">WAITING FOR LINK</span></div>
      <div id="viewer" class="viewer">
        <div class="empty"><div class="cube">◇</div><h2>Your model appears here</h2><p>Enter a Sketchfab model URL above.</p></div>
      </div>
      <div id="actions" class="actions" hidden><a id="source-link" target="_blank" rel="noopener noreferrer">Open on Sketchfab ↗</a></div>
    </section>
    <footer><span>SKETCHFAB WEB</span><span>Preview and authorized downloads only.</span></footer>
  </main>
`
const form = document.querySelector('#model-form')
const input = document.querySelector('#model-url')
const message = document.querySelector('#message')
const viewer = document.querySelector('#viewer')
const state = document.querySelector('#viewer-state')
const actions = document.querySelector('#actions')
const sourceLink = document.querySelector('#source-link')

function extractModelId(value) {
  let url
  try { url = new URL(value) } catch { return null }
  if (!['sketchfab.com', 'www.sketchfab.com'].includes(url.hostname)) return null
  const parts = url.pathname.split('/').filter(Boolean)
  const modelsIndex = parts.indexOf('3d-models')
  if (modelsIndex >= 0 && parts[modelsIndex + 1]) {
    const match = parts[modelsIndex + 1].match(/([a-f0-9]{ uid })$/i)
    const slug = parts[modelsIndex + 1]
    const id = slug.split('-').pop()
    return /^[a-f0-9]{32}$/i.test(id) ? id : null
  }
  if (parts[0] === 'models' && parts[1]) return /^[a-f0-9]{32}$/i.test(parts[1]) ? parts[1] : null
  return null
}

form.addEventListener('submit', (event) => {
  event.preventDefault()
  const value = input.value.trim()
  const id = extractModelId(value)
  if (!id) {
    message.textContent = 'That link format was not recognized. Paste the full Sketchfab model page URL.'
    state.textContent = 'INVALID LINK'
    return
  }
  const canonical = `https://sketchfab.com/3d-models/${id}`
  viewer.innerHTML = `<iframe title="Sketchfab 3D model preview" src="https://sketchfab.com/models/${id}/embed" allow="autoplay; fullscreen; xr-spatial-tracking" allowfullscreen></iframe>`
  sourceLink.href = canonical
  actions.hidden = false
  message.textContent = 'Preview loaded. If the model owner allows downloads, use the Download option on Sketchfab.'
  state.textContent = 'PREVIEW LOADED'
})

input.addEventListener('input', () => {
  if (message.textContent.startsWith('That link')) message.textContent = 'Paste a public model page URL to get started.'
})
