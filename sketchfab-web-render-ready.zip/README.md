# Sketchfab Web

A mobile-first static website that previews public Sketchfab model pages using the official Sketchfab embed player.

## Render deployment

Create a **Static Site** in Render and connect this GitHub repository.

- **Build Command:** `npm install && npm run build`
- **Publish Directory:** `dist`

No environment variables are required for this preview-only version.

## Local development

```bash
npm install
npm run dev
```

## Scope

This starter previews Sketchfab models using the official embed player. It does not extract model files or bypass owner download permissions. If the model owner enables downloads, use the official Download option on Sketchfab.
