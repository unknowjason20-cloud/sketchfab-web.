import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express();
app.use(express.json({limit:"32kb"}));
app.use(express.static(path.join(__dirname,"dist")));
const UID_RE=/^[a-f0-9]{32}$/i;
app.post("/api/download-link",async(req,res)=>{
  const {uid,token,authType="Bearer"}=req.body||{};
  if(!UID_RE.test(String(uid||""))) return res.status(400).json({error:"Invalid Sketchfab model UID or URL."});
  if(typeof token!=="string"||token.trim().length<8) return res.status(400).json({error:"Enter your own Sketchfab API token or OAuth access token."});
  if(!["Bearer","Token"].includes(authType)) return res.status(400).json({error:"Unsupported authentication type."});
  try{
    const r=await fetch(`https://api.sketchfab.com/v3/models/${uid}/download`,{headers:{Authorization:`${authType} ${token.trim()}`,Accept:"application/json"}});
    const body=await r.json().catch(()=>({}));
    if(!r.ok){
      const messages={400:"This model is not downloadable through Sketchfab's official API.",401:"Sketchfab rejected the token. Check the token and authentication type.",403:"Your account does not have permission to download this model.",404:"Model not found.",429:"Sketchfab rate limit reached. Wait before retrying."};
      return res.status(r.status).json({error:messages[r.status]||body.detail||`Sketchfab API returned ${r.status}.`});
    }
    if(!body.gltf?.url) return res.status(502).json({error:"Sketchfab did not return a glTF archive for this model."});
    res.json({url:body.gltf.url,expires:body.gltf.expires||300,format:"glTF ZIP"});
  }catch(e){res.status(502).json({error:"Could not contact Sketchfab API: "+e.message});}
});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"dist","index.html")));
const port=process.env.PORT||3000;
app.listen(port,"0.0.0.0",()=>console.log(`Sketchfab Web listening on ${port}`));
