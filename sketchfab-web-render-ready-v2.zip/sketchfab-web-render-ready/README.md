# Sketchfab Web Downloader — Render deployment

This is a Render-ready web app using Sketchfab's **official Download API**. It is not a one-click conversion of the Chrome extension's private viewer-capture pipeline.

## Render settings

Create a **Web Service** from this repository:
- Runtime: Node
- Build Command: `npm install`
- Start Command: `npm start`
- Root Directory: leave blank

Do not use Static Site for this package; the server provides `/api/download-link`.

## Use

1. Open the deployed site.
2. Enter your own Sketchfab API token or OAuth access token.
3. Choose `Bearer` for OAuth access tokens or `Token` for API tokens.
4. Paste Sketchfab model URLs/UIDs, one per line.
5. Start downloads. Batch requests run sequentially.

The token is sent to the app server only when requesting a download link. The server does not persist it. For a public deployment with multiple users, add HTTPS (Render provides it), rate limiting, and preferably implement Sketchfab OAuth instead of asking users to paste tokens.

## Important feature boundaries

The official endpoint `GET https://api.sketchfab.com/v3/models/{uid}/download` requires authentication and only returns download links for models downloadable by that account. The returned glTF archive is prepared by Sketchfab and normally includes its textures.

This app therefore does **not** claim to support the extension's custom texture on/off filtering, 2K/4K texture downscaling, GLB-only repacking, decryption of non-downloadable viewer assets, or the original extension's OSGJS conversion pipeline. The official Download API does not expose those options. It also cannot download models that the account is not authorized to download.

See https://sketchfab.com/developers/download-api/downloading-models and https://docs.sketchfab.com/data-api/v3/.
