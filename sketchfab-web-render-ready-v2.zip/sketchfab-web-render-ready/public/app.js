const $=id=>document.getElementById(id);let stopRequested=false,running=false;
function extractUid(s){const m=String(s).match(/sketchfab\.com\/(?:3d-models\/[^/?#]+-|models\/)([a-f0-9]{32})/i)||String(s).match(/\b([a-f0-9]{32})\b/i);return m?.[1]?.toLowerCase()||null}
function addJob(label){const d=document.createElement("div");d.className="job";const b=document.createElement("strong"),s=document.createElement("small");b.textContent=label;s.textContent="Queued";d.append(b,s);$("queue").prepend(d);return(msg,state)=>{s.textContent=msg;d.className="job "+(state||"")}}
$("showToken").onclick=()=>{const t=$("token");t.type=t.type==="password"?"text":"password";$("showToken").textContent=t.type==="password"?"Show":"Hide"};
$("clear").onclick=()=>{$("queue").replaceChildren();$("summary").textContent=""};
$("stopNow").onclick=()=>{stopRequested=true;$("stopNow").disabled=true;$("summary").textContent="Will stop after the current model."};
$("start").onclick=async()=>{if(running)return;const token=$("token").value.trim();if(!token){$("summary").textContent="Enter your Sketchfab token first.";return}
const lines=$("urls").value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);const seen=new Set(),uids=[];for(const line of lines){const uid=extractUid(line);if(uid&&!seen.has(uid)){uids.push(uid);seen.add(uid)}}
if(!uids.length){$("summary").textContent="Paste at least one valid Sketchfab model URL or UID.";return}
running=true;stopRequested=false;$("start").disabled=true;$("stopNow").disabled=false;let ok=0,fail=0;
for(let i=0;i<uids.length;i++){if(stopRequested)break;const uid=uids[i],update=addJob(uid);update(`[${i+1}/${uids.length}] Requesting official download link…`);
try{const r=await fetch("/api/download-link",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({uid,token,authType:$("auth").value})});const data=await r.json();if(!r.ok)throw new Error(data.error||`Request failed (${r.status})`);const a=document.createElement("a");a.href=data.url;a.download=`sketchfab-${uid}.zip`;a.target="_blank";a.rel="noopener";document.body.append(a);a.click();a.remove();update(`Download link opened · ${data.format} · temporary link expires in about ${data.expires}s`,"ok");ok++}
catch(e){update("Failed: "+e.message,"err");fail++}
$("summary").textContent=`Completed ${i+1}/${uids.length} · ${ok} started · ${fail} failed`;
if(!$("batch").checked)break;
}
running=false;$("start").disabled=false;$("stopNow").disabled=true;$("summary").textContent=`Finished · ${ok} download(s) started · ${fail} failed${stopRequested?" · stopped":""}`;if($("dev").checked)console.info("Sketchfab Web job summary",{ok,fail,uids});
};