# Sketchfab Public Downloader — Extension + Website

Chrome (Manifest V3) extension **and** a production website that download **public**
Sketchfab 3D models as a **glTF (`.glb`) ZIP**. No Sketchfab account, login, password,
cookie, or API token. Works on models that have no official Download button.

UI: **English**, **Russian**, and **Simplified Chinese**. Light and dark themes.

> The website is an *additional* application. The original extension is preserved,
> untouched, in [`extension/`](extension/) and works independently. Both share one
> copy of the processing pipeline (`extension/lib/`), which the website imports
> unmodified — see [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

Repository origin: https://github.com/seryi882/sketchfab-downloader-extension

---

## Live website

| View | What it does |
|---|---|
| **Download** | Paste a public model URL/UID → real pipeline runs in a Web Worker → GLB ZIP is saved. Real progress bar (driven by pipeline log lines), full log pane, copy/save log. |
| **Bulk** | One URL per line, per-item progress, overall progress, success/failure tracking, stop-after-current, retry failed (all or per item). |
| **Settings** | Theme, language (EN/RU/ZH), archive (Full / GLB only), texture size (Original / ≤2K / ≤4K) — applied immediately. **Download textures** and **Developer mode** — applied with **Apply settings**, exactly like the extension. Persisted in localStorage. |

Design: black / dark-charcoal with crimson accents, rounded cards, responsive
(desktop / tablet / mobile), dark + light themes.

## What it does

| Feature | Details |
|---|---|
| Public models | Mesh + optional textures from the public viewer |
| glTF output | `.glb` with PBR materials (Blender: File → Import → glTF 2.0) |
| Textures | Optional, off by default. Protected maps are descrambled with the viewer `pk` key |
| Bulk download | Paste many public links; each model saved as its own ZIP |
| Heavy models | Decrypt / descramble / zip run in a Web Worker (the website equivalent of the extension's offscreen document) |
| Dev mode | Detailed log in the UI; `download-log.txt` is added to the ZIP |

### ZIP contents

**Full** archive:
```text
ModelName-abcd1234.zip              # or ModelName-abcd1234-textures.zip
├── ModelName.glb
├── model.gltf + model.bin
├── textures/                       # only if textures are enabled
├── file.osgjs
├── model_file.bin
├── model_file_wireframe.bin        # if present
├── README.txt
├── info.json
└── download-log.txt                # only if developer mode is on
```
**GLB only** keeps `ModelName.glb`, `README.txt`, `info.json` (and `download-log.txt` in dev mode).

### How it works

1. Reads the public embed/viewer page (UID, materials, mesh URLs, `diter.b`).
2. Extracts the current static decrypt key from live Sketchfab JS.
3. Downloads `.binz` payloads and decrypts them with WASM.
4. If textures are on: fetches public maps in parallel (3 at a time), picks Original / ≤2K / ≤4K, descrambles maps that have `pk`, packs ORM maps.
5. Converts osgjs → glTF (Y-up so the model stands in Blender).
6. Packs a deflated ZIP and saves it.

On the website, Sketchfab requests go through the site's own **allowlisted proxy**
(`/api/proxy`, sketchfab.com hosts only) because a website origin gets no CORS grant
from Sketchfab and cannot set the headers the viewer endpoints expect. No cookies or
credentials are forwarded. See [Security](#security--privacy).

**Website limitation (stated honestly):** the extension's WebGL viewer-capture hook
must run inside sketchfab.com's page, so it cannot exist on a website. The website
relies on the preserved pk-descramble path instead — the pipeline's documented
no-capture mode. Details: [docs/FEATURE_PRESERVATION.md](docs/FEATURE_PRESERVATION.md).

---

## Run locally

Requirements: Node.js ≥ 18. **Zero npm dependencies.**

```bash
git clone <your-fork-url> sketchfab-downloader-web
cd sketchfab-downloader-web
npm run build     # production build check (files present, JS parses)
npm start         # http://localhost:3000  (PORT env var honoured)
npm test          # 220 tests: 204 original extension tests + 16 website tests
```

## Deploy to Render

This repo ships a Render Blueprint ([`render.yaml`](render.yaml)):

1. Push this repository to GitHub.
2. Render → **New → Blueprint** → select the repo → **Apply**.
   (Or manually: New **Web Service**, runtime Node, build command `npm run build`,
   start command `npm start`, health-check path `/api/health`.)
3. Done — Render sets `PORT` automatically; the server binds `0.0.0.0:$PORT`.

No environment variables or secrets are required. `.env.example` documents the only
optional variable (`PORT`, local use). Free-plan note: the service sleeps when idle;
the first request after sleep takes ~30–60 s to wake.

## Install the Chrome extension (unchanged)

1. Chrome → `chrome://extensions` → enable **Developer mode**.
2. **Load unpacked** → select the [`extension/`](extension/) folder.
3. After every extension reload, refresh the Sketchfab model page (`Ctrl+F5`).

## Project architecture

```text
extension/            Original MV3 extension — untouched (popup, panel, bulk,
                      offscreen, content scripts, lib/, test/ — 204 tests)
public/               Website: index.html, css/styles.css,
                      js/app.js (shell), js/chrome-shim.js (chrome.* → web),
                      js/web-download.js (worker client), js/download-worker.js
server.js             Zero-dependency Node server: static site, /lib → extension/lib,
                      /api/health, /api/proxy (allowlisted)
server/proxy-policy.mjs  SSRF policy for the proxy (pure, unit-tested)
test-web/             Website tests (proxy policy, chrome shim, live server routes)
docs/                 AUDIT.md · ARCHITECTURE.md · FEATURE_PRESERVATION.md · TEST_RESULTS.md
render.yaml           Render Blueprint
```

Full detail: [docs/AUDIT.md](docs/AUDIT.md) (complete original-project audit),
[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md),
[docs/FEATURE_PRESERVATION.md](docs/FEATURE_PRESERVATION.md) (feature-by-feature checklist),
[docs/TEST_RESULTS.md](docs/TEST_RESULTS.md) (verified test + live-download results).

## Security & privacy

- Never requests Sketchfab passwords, cookies, or tokens; only public viewer/CDN data.
- Does not bypass private-model permissions or access restrictions — the original
  pipeline's own checks reject private / non-`.binz` models.
- Proxy SSRF policy: `https:` only, hostname must be `sketchfab.com` or a subdomain,
  no embedded credentials, no IP-literal/localhost destinations, redirect targets
  re-validated, 250 MB response cap, 120 s timeout, no cookies forwarded.
- All user input is validated (UID parsing is the original `extractUid`).
- The server stores nothing about users; settings live only in the browser's localStorage.
- Respect [Sketchfab's Terms](https://sketchfab.com/terms) and each author's licence.

## Troubleshooting

| Symptom | Fix |
|---|---|
| "Could not read public viewer data" | The model is private, deleted, or not public — the site cannot (and will not) bypass that. |
| "not in the current encrypted .binz format" | Old-format or restricted model; the original pipeline only supports the current public format. |
| Download seems stuck on a huge model | 4K/8K texture packs are large; watch the log pane — progress is real pipeline output. Turn textures off for a fast mesh-only ZIP. |
| Textures look striped on a model | Its maps had no usable `pk` variant and (unlike the extension) the website has no viewer captures; the affected maps are listed in `MISSING_BLIT.txt` (Full archive). Try the extension for that model. |
| Render site is slow on first load | Free-plan cold start; subsequent loads are fast. |
| Extension panel missing after reload | Refresh the Sketchfab page with `Ctrl+F5` after reloading the extension. |

## License

[GNU General Public License v3.0](LICENSE) — Copyright (C) 2026 seryi882.
Preserved from the original project.
