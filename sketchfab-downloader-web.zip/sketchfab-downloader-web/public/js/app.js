/**
 * Sketchfab Downloader — website application.
 *
 * All downloading, settings, i18n, progress and saving behaviour is provided
 * by the ORIGINAL extension modules in /lib (served from extension/lib):
 *   settings.js, i18n.js, ui-settings.js, ui-progress.js, sf-api.js, save.js
 * and the original pipeline itself, run by web-download.js in a Web Worker.
 * This file is only the website shell: navigation, wiring and rendering.
 */
import { installChromeShim } from "./chrome-shim.js";

installChromeShim();

import { t, createLangSwitch, updateLangSwitch, LANGS } from "/lib/i18n.js";
import {
  loadPrefs, savePrefs, applyTheme, normalizePrefs, prefsFromUi, jobFlagsFromPrefs, GITHUB_URL,
} from "/lib/settings.js";
import { isJobDirty, paintSettingsFlash, formatJobStatus, bindPillSwitch, bindThemeSwitch } from "/lib/ui-settings.js";
import { progressFromMessage, saveTextFile } from "/lib/ui-progress.js";
import { extractUid } from "/lib/sf-api.js";
import { saveZip } from "/lib/save.js";
import { downloadModelInWeb } from "./web-download.js";

/* ---------- Web-only strings (original keys come from lib/i18n.js) ---------- */
const WEB = {
  en: {
    heroTitle: "Public Sketchfab models, as glTF.",
    heroSub: "Paste a public model link. The original extension pipeline — WASM decrypt, texture descramble, osgjs → glTF conversion — runs in your browser and hands you a real ZIP.",
    urlLabel: "Sketchfab model URL or UID",
    invalidUrl: "That does not look like a public Sketchfab model URL. Paste a link like https://sketchfab.com/3d-models/name-<32-char id>, or a bare 32-char UID.",
    feat1Title: "Real GLB output", feat1Body: "PBR materials, skins, morphs and animations converted from the public viewer scene — import the .glb straight into Blender.",
    feat2Title: "Textures, descrambled", feat2Body: "Optional texture download with the original pk descramble and ORM packing. Original size, ≤2K or ≤4K — your choice in Settings.",
    feat3Title: "No account, no token", feat3Body: "Only public viewer data is used. No Sketchfab login, password, cookie or API key is ever requested.",
    howTitle: "How it works",
    how1: "Reads the public embed/viewer page (UID, materials, mesh URLs, diter.b).",
    how2: "Extracts the current static decrypt key from live Sketchfab JS.",
    how3: "Downloads the .binz payloads and decrypts them with the original WASM module, in a Web Worker.",
    how4: "If textures are on: fetches public maps, descrambles protected maps, packs ORM textures.",
    how5: "Converts osgjs → glTF (Y-up, so the model stands correctly in Blender) and packs a deflated ZIP.",
    formatsLine: "Output: Full archive (GLB + model.gltf/.bin + file.osgjs + textures/ + README.txt + info.json) or GLB-only — set in Settings.",
    legalLine: "For personal use of public viewer data. Follow Sketchfab's Terms and each author's licence. Private and download-restricted models are not bypassed.",
    bulkTitleShort: "Bulk", bulkRetry: "Retry failed",
    savedAs: "Saved {name} ({size})", includesGlbShort: "includes .glb",
    logEmpty: "No log yet — run a download.",
  },
  ru: {
    heroTitle: "Публичные модели Sketchfab — в glTF.",
    heroSub: "Вставьте ссылку на публичную модель. Оригинальный конвейер расширения — WASM-расшифровка, дескрембл текстур, конверсия osgjs → glTF — работает в вашем браузере и выдаёт настоящий ZIP.",
    urlLabel: "Ссылка на модель Sketchfab или UID",
    invalidUrl: "Это не похоже на ссылку на публичную модель Sketchfab. Вставьте ссылку вида https://sketchfab.com/3d-models/name-<id из 32 символов> или сам UID из 32 символов.",
    feat1Title: "Настоящий GLB", feat1Body: "PBR-материалы, скины, морфы и анимации из публичной сцены вьюера — .glb импортируется прямо в Blender.",
    feat2Title: "Текстуры с дескремблом", feat2Body: "Опциональная загрузка текстур с оригинальным pk-дескремблом и упаковкой ORM. Оригинал, ≤2K или ≤4K — на выбор в Настройках.",
    feat3Title: "Без аккаунта и токена", feat3Body: "Используются только публичные данные вьюера. Логин, пароль, куки или API-ключ Sketchfab никогда не запрашиваются.",
    howTitle: "Как это работает",
    how1: "Читает публичную страницу embed/вьюера (UID, материалы, URL мешей, diter.b).",
    how2: "Извлекает актуальный статический ключ расшифровки из живого JS Sketchfab.",
    how3: "Скачивает .binz и расшифровывает оригинальным WASM-модулем в Web Worker.",
    how4: "Если текстуры включены: скачивает публичные карты, дескремблит защищённые, упаковывает ORM.",
    how5: "Конвертирует osgjs → glTF (Y-up, модель стоит правильно в Blender) и упаковывает ZIP с deflate.",
    formatsLine: "Результат: полный архив (GLB + model.gltf/.bin + file.osgjs + textures/ + README.txt + info.json) или только GLB — в Настройках.",
    legalLine: "Для личного использования публичных данных вьюера. Соблюдайте условия Sketchfab и лицензии авторов. Приватные модели и модели с ограничением загрузки не обходятся.",
    bulkTitleShort: "Массовая", bulkRetry: "Повторить ошибки",
    savedAs: "Сохранено {name} ({size})", includesGlbShort: "есть .glb",
    logEmpty: "Лога пока нет — запустите загрузку.",
  },
  zh: {
    heroTitle: "将 Sketchfab 公共模型转换为 glTF。",
    heroSub: "粘贴公共模型链接。原扩展的处理流程——WASM 解密、纹理解扰、osgjs → glTF 转换——将在浏览器中运行，并生成真实的 ZIP 文件。",
    urlLabel: "Sketchfab 模型链接或 UID",
    invalidUrl: "这不像是 Sketchfab 公共模型链接。请粘贴类似 https://sketchfab.com/3d-models/name-<32 位 id> 的链接，或 32 位 UID。",
    feat1Title: "真实的 GLB 输出", feat1Body: "从公共查看器场景转换 PBR 材质、骨骼、变形和动画——.glb 可直接导入 Blender。",
    feat2Title: "纹理解扰", feat2Body: "可选下载纹理，使用原始 pk 解扰和 ORM 打包。原始尺寸、≤2K 或 ≤4K——在设置中选择。",
    feat3Title: "无需账号或令牌", feat3Body: "仅使用公共查看器数据。从不要求 Sketchfab 登录、密码、Cookie 或 API 密钥。",
    howTitle: "工作原理",
    how1: "读取公共 embed/查看器页面（UID、材质、网格 URL、diter.b）。",
    how2: "从 Sketchfab 实时 JS 中提取当前静态解密密钥。",
    how3: "下载 .binz 并在 Web Worker 中用原始 WASM 模块解密。",
    how4: "若开启纹理：获取公共贴图、解扰受保护贴图、打包 ORM 纹理。",
    how5: "将 osgjs 转换为 glTF（Y-up，模型在 Blender 中正确直立）并打包为 ZIP。",
    formatsLine: "输出：完整归档（GLB + model.gltf/.bin + file.osgjs + textures/ + README.txt + info.json）或仅 GLB——在设置中选择。",
    legalLine: "仅供个人使用公共查看器数据。请遵守 Sketchfab 条款及每位作者的许可证。不会绕过私有或受限模型。",
    bulkTitleShort: "批量", bulkRetry: "重试失败项",
    savedAs: "已保存 {name}（{size}）", includesGlbShort: "包含 .glb",
    logEmpty: "暂无日志——请先运行一次下载。",
  },
};

function tt(lang, key, vars) {
  const web = WEB[lang] && WEB[lang][key];
  let s = web !== undefined ? web : t(lang, key, vars);
  if (vars && typeof s === "string") {
    for (const [k, v] of Object.entries(vars)) s = s.replace(new RegExp(`\\{${k}\\}`, "g"), String(v));
  }
  return s;
}

const $ = (id) => document.getElementById(id);
const els = {
  url: $("model-url"), btnDownload: $("btn-download"), urlHint: $("url-hint"),
  progressWrap: $("progress-wrap"), progressBar: $("progress-bar"),
  progressLabel: $("progress-label"), progressPct: $("progress-pct"),
  result: $("result-box"), error: $("error-box"),
  logPane: $("log-pane"), logBadge: $("log-badge"), logDetails: $("log-details"),
  jobStatus: $("job-status"), jobStatusSettings: $("job-status-settings"),
  texToggle: $("tex-toggle"), devToggle: $("dev-toggle"),
  flash: $("settings-flash"),
  bulkLinks: $("bulk-links"), bulkLog: $("bulk-log"), bulkSummary: $("bulk-summary"),
  bulkStart: $("btn-bulk-start"), bulkStop: $("btn-bulk-stop"), bulkRetry: $("btn-bulk-retry"),
  bulkProgressWrap: $("bulk-progress-wrap"), bulkProgressBar: $("bulk-progress-bar"),
  bulkProgressLabel: $("bulk-progress-label"), bulkProgressPct: $("bulk-progress-pct"),
};

let lang = "en";
let appliedPrefs = normalizePrefs({});
let pendingPrefs = normalizePrefs({});
let downloading = false;
let logLines = [];

/* ---------------- i18n / theme ---------------- */
function applyI18n() {
  document.documentElement.lang = lang === "zh" ? "zh-CN" : lang;
  document.title = `${tt(lang, "appName")} — Web`;
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    el.textContent = tt(lang, el.getAttribute("data-i18n"));
  });
  els.bulkLinks.placeholder = t(lang, "bulkPlaceholder");
  updateLangSwitch(document.body, lang);
  paintJobStatus();
}

function paintJobStatus() {
  const line = formatJobStatus(appliedPrefs, t, lang);
  els.jobStatus.textContent = line;
  els.jobStatusSettings.textContent = line;
}

function paintFlash({ dirty = false, ok = false } = {}) {
  paintSettingsFlash(els.flash, { dirty, appliedOk: ok, t, lang });
}

async function setLang(code) {
  const next = await savePrefs({ lang: code });
  lang = next.lang;
  appliedPrefs = next; pendingPrefs = { ...pendingPrefs, lang: next.lang };
  applyI18n();
  repaintPills();
}

async function setTheme(theme) {
  const next = await savePrefs({ theme });
  appliedPrefs = next; pendingPrefs = { ...pendingPrefs, theme: next.theme };
  applyTheme(document.documentElement, next.theme);
  repaintPills();
}

/* ---------------- settings wiring ---------------- */
let repaintPills = () => {};
function wireSettings() {
  const repaintTheme = bindThemeSwitch($("theme-switch"), {
    getTheme: () => pendingPrefs.theme, onPick: (code) => setTheme(code), t, lang,
  });
  const repaintPack = bindPillSwitch($("pack-switch"), {
    items: [
      { code: "full", label: t(lang, "packFull") },
      { code: "glb", label: t(lang, "packGlb") },
    ],
    get: () => pendingPrefs.packMode,
    onPick: async (code) => {
      const next = await savePrefs({ packMode: code });
      appliedPrefs = next; pendingPrefs = { ...pendingPrefs, packMode: next.packMode };
      paintJobStatus(); repaintPills();
    },
  });
  const repaintRes = bindPillSwitch($("res-switch"), {
    items: [
      { code: "0", label: t(lang, "texSizeOrig") },
      { code: "2048", label: t(lang, "texSize2k") },
      { code: "4096", label: t(lang, "texSize4k") },
    ],
    get: () => String(pendingPrefs.maxTextureEdge),
    onPick: async (code) => {
      const next = await savePrefs({ maxTextureEdge: Number(code) });
      appliedPrefs = next; pendingPrefs = { ...pendingPrefs, maxTextureEdge: next.maxTextureEdge };
      paintJobStatus(); repaintPills();
    },
  });
  repaintPills = () => { repaintTheme(); repaintPack(); repaintRes(); };

  const onJobToggle = () => {
    pendingPrefs = prefsFromUi({
      texToggle: els.texToggle, devToggle: els.devToggle,
      theme: pendingPrefs.theme, lang: pendingPrefs.lang,
      packMode: pendingPrefs.packMode, maxTextureEdge: pendingPrefs.maxTextureEdge,
    });
    paintFlash({ dirty: isJobDirty(pendingPrefs, appliedPrefs) });
  };
  els.texToggle.addEventListener("change", onJobToggle);
  els.devToggle.addEventListener("change", onJobToggle);

  $("btn-save-settings").addEventListener("click", async () => {
    // Original semantics: Apply persists ONLY the two job flags; theme/lang/
    // pack/edge were already saved the moment they changed.
    appliedPrefs = await savePrefs({ textures: els.texToggle.checked, devMode: els.devToggle.checked });
    pendingPrefs = { ...appliedPrefs };
    els.texToggle.checked = appliedPrefs.textures;
    els.devToggle.checked = appliedPrefs.devMode;
    paintJobStatus();
    paintFlash({ ok: true });
    setTimeout(() => paintFlash({}), 2600);
  });

  $("theme-toggle").addEventListener("click", () => {
    setTheme(pendingPrefs.theme === "dark" ? "light" : "dark");
  });
}

/* ---------------- logging / progress ---------------- */
function appendLog(line) {
  const s = String(line || "");
  logLines.push(s);
  if (logLines.length > 1200) logLines = logLines.slice(-1200);
  els.logPane.textContent = logLines.join("\n");
  els.logPane.scrollTop = els.logPane.scrollHeight;
  els.logBadge.textContent = `${logLines.length} lines`;
  const pct = progressFromMessage(s);
  if (pct != null && downloading) {
    els.progressBar.style.width = pct + "%";
    els.progressPct.textContent = pct + "%";
  }
  if (s) els.progressLabel.textContent = s;
}
function clearLog() {
  logLines = [];
  els.logPane.textContent = "";
  els.logBadge.textContent = "";
}

function fmtBytes(n) {
  if (!n && n !== 0) return "";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(2)} MB`;
}

/* ---------------- single download ---------------- */
function jobOpts() {
  const flags = jobFlagsFromPrefs(appliedPrefs);
  return {
    devMode: flags.devMode,
    downloadTextures: flags.downloadTextures,
    packMode: flags.packMode,
    maxTextureEdge: flags.maxTextureEdge,
  };
}

async function runDownload(rawUrl, { save = true } = {}) {
  const uid = extractUid(String(rawUrl || ""));
  if (!uid) throw new Error(tt(lang, "invalidUrl"));
  const url = /^https?:\/\//i.test(String(rawUrl).trim())
    ? String(rawUrl).trim()
    : `https://sketchfab.com/3d-models/${uid}`;
  const result = await downloadModelInWeb(url, appendLog, jobOpts());
  if (save) await saveZip(result.zip, result.zipName);
  return result;
}

async function onDownload() {
  if (downloading) return;
  const raw = els.url.value.trim();
  if (!extractUid(raw)) {
    els.error.hidden = false;
    els.error.textContent = tt(lang, "invalidUrl");
    els.result.hidden = true;
    els.url.focus();
    return;
  }
  downloading = true;
  els.btnDownload.disabled = true;
  els.btnDownload.textContent = t(lang, "downloading");
  els.error.hidden = true; els.result.hidden = true;
  els.progressWrap.hidden = false;
  els.progressBar.style.width = "0%"; els.progressPct.textContent = "";
  els.logDetails.open = appliedPrefs.devMode;
  appendLog(`${t(lang, "starting")} ${raw}`);
  try {
    const result = await runDownload(raw);
    els.progressBar.style.width = "100%"; els.progressPct.textContent = "100%";
    els.result.hidden = false;
    els.result.textContent =
      `✅ ${tt(lang, "savedAs", { name: result.zipName, size: fmtBytes(result.zipBytes) })}` +
      (result.hasGlb ? ` ${tt(lang, "includesGlbShort")}` : "") +
      ` · ${result.name} ${t(lang, "by")} ${result.author}`;
  } catch (e) {
    els.error.hidden = false;
    els.error.textContent = `❌ ${e && e.message ? e.message : e}`;
    appendLog(`ERROR: ${e && e.message ? e.message : e}`);
    if (e && e.logText) { logLines = String(e.logText).split("\n"); els.logPane.textContent = e.logText; }
  } finally {
    downloading = false;
    els.btnDownload.disabled = false;
    els.btnDownload.textContent = t(lang, "panelDownload");
  }
}

/* ---------------- bulk ---------------- */
let bulkRunning = false;
let bulkStop = false;
let bulkItems = []; // { uid, url, state: queued|run|ok|err, result?, error?, row }

function parseLinks(text) {
  const lines = String(text || "").split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const out = []; const seen = new Set();
  for (const line of lines) {
    const uid = extractUid(line);
    if (!uid) continue;
    if (seen.has(uid)) continue;
    seen.add(uid);
    out.push({ uid, url: /^https?:\/\//i.test(line) ? line : `https://sketchfab.com/3d-models/${uid}`, state: "queued" });
  }
  return out;
}

function renderBulkRow(item) {
  if (!item.row) {
    const div = document.createElement("div");
    div.className = "bulk-item";
    div.innerHTML = `<div class="title"></div><div class="msg"></div>`;
    els.bulkLog.prepend(div);
    item.row = div;
  }
  const div = item.row;
  div.querySelector(".title").textContent = item.url;
  div.querySelector(".msg").textContent = item.msg || t(lang, "bulkQueued");
  div.classList.remove("ok", "err", "run");
  if (item.state === "ok" || item.state === "err" || item.state === "run") div.classList.add(item.state);
  let retryBtn = div.querySelector(".retry-one");
  if (item.state === "err" && !bulkRunning) {
    if (!retryBtn) {
      retryBtn = document.createElement("button");
      retryBtn.type = "button"; retryBtn.className = "btn-soft retry-one";
      retryBtn.textContent = tt(lang, "bulkRetry");
      retryBtn.addEventListener("click", () => runBulk([item]));
      div.appendChild(retryBtn);
    }
  } else if (retryBtn) retryBtn.remove();
}

function paintBulkSummary() {
  const total = bulkItems.length;
  const done = bulkItems.filter((i) => i.state === "ok" || i.state === "err").length;
  const ok = bulkItems.filter((i) => i.state === "ok").length;
  const fail = bulkItems.filter((i) => i.state === "err").length;
  els.bulkProgressWrap.hidden = total === 0;
  const pct = total ? Math.round((done / total) * 100) : 0;
  els.bulkProgressBar.style.width = pct + "%";
  els.bulkProgressPct.textContent = total ? pct + "%" : "";
  els.bulkProgressLabel.textContent = total ? `${done} / ${total}` : "";
  els.bulkRetry.disabled = bulkRunning || fail === 0;
  if (!bulkRunning && total) {
    els.bulkSummary.textContent = bulkStop
      ? t(lang, "bulkStopped", { ok, fail })
      : t(lang, "bulkFinished", { ok, fail });
  }
}

async function runBulk(items) {
  if (bulkRunning) return;
  bulkRunning = true; bulkStop = false;
  els.bulkStart.disabled = true; els.bulkStop.disabled = false; els.bulkRetry.disabled = true;
  let idx = 0;
  for (const item of items) {
    if (bulkStop) break;
    idx++;
    item.state = "run"; item.msg = `[${idx}/${items.length}] ${t(lang, "bulkStarting")}`;
    renderBulkRow(item);
    els.bulkSummary.textContent = `${t(lang, "bulkDownloading")} ${idx} / ${items.length}…`;
    try {
      const result = await downloadModelInWeb(item.url, (msg) => {
        item.msg = `[${idx}/${items.length}] ${msg}`;
        renderBulkRow(item);
      }, jobOpts());
      await saveZip(result.zip, result.zipName);
      item.state = "ok";
      item.msg = `✅ ${result.name} — ${result.zipName}${result.hasGlb ? " (glb)" : ""} · ${fmtBytes(result.zipBytes)}`;
    } catch (e) {
      item.state = "err";
      item.msg = `❌ ${e && e.message ? e.message : e}`;
      item.error = e;
    }
    renderBulkRow(item);
    paintBulkSummary();
  }
  bulkRunning = false;
  els.bulkStart.disabled = false; els.bulkStop.disabled = true;
  paintBulkSummary();
  for (const item of bulkItems) renderBulkRow(item);
}

/* ---------------- navigation ---------------- */
function showView(name) {
  document.querySelectorAll(".view").forEach((v) => v.classList.toggle("active", v.id === `view-${name}`));
  document.querySelectorAll(".nav-btn").forEach((b) => b.classList.toggle("active", b.getAttribute("data-nav") === name));
  if (location.hash !== `#/${name}`) history.replaceState(null, "", `#/${name}`);
}

/* ---------------- init ---------------- */
async function init() {
  appliedPrefs = await loadPrefs();
  pendingPrefs = { ...appliedPrefs };
  lang = appliedPrefs.lang;
  if (!LANGS.includes(lang)) lang = "en";

  applyTheme(document.documentElement, appliedPrefs.theme);
  els.texToggle.checked = appliedPrefs.textures;
  els.devToggle.checked = appliedPrefs.devMode;

  wireSettings();
  repaintPills();

  for (const hostId of ["lang-switch", "lang-switch-settings"]) {
    const host = $(hostId);
    if (host) host.appendChild(createLangSwitch(lang, (code) => setLang(code)));
  }
  applyI18n();
  els.logPane.textContent = tt(lang, "logEmpty");

  document.querySelectorAll("[data-nav]").forEach((el) => {
    el.addEventListener("click", (e) => { e.preventDefault(); showView(el.getAttribute("data-nav")); });
  });
  const fromHash = (location.hash || "").replace("#/", "");
  if (["download", "bulk", "settings"].includes(fromHash)) showView(fromHash);

  els.btnDownload.addEventListener("click", onDownload);
  els.url.addEventListener("keydown", (e) => { if (e.key === "Enter") onDownload(); });

  $("btn-copy-log").addEventListener("click", async () => {
    try { await navigator.clipboard.writeText(logLines.join("\n")); appendLog(t(lang, "logCopied")); } catch { /* clipboard blocked */ }
  });
  $("btn-save-log").addEventListener("click", () => { saveTextFile("download-log.txt", logLines.join("\n")); });
  $("btn-clear-log").addEventListener("click", clearLog);

  els.bulkStart.addEventListener("click", () => {
    bulkItems = parseLinks(els.bulkLinks.value);
    if (!bulkItems.length) { els.bulkSummary.textContent = t(lang, "bulkNoLinks"); return; }
    els.bulkLog.innerHTML = "";
    for (const item of bulkItems) { item.row = null; renderBulkRow(item); }
    paintBulkSummary();
    runBulk(bulkItems);
  });
  els.bulkStop.addEventListener("click", () => {
    bulkStop = true; els.bulkStop.disabled = true;
    els.bulkSummary.textContent = t(lang, "bulkStopping");
  });
  els.bulkRetry.addEventListener("click", () => {
    const failed = bulkItems.filter((i) => i.state === "err");
    for (const item of failed) { item.state = "queued"; item.msg = t(lang, "bulkQueued"); renderBulkRow(item); }
    runBulk(failed);
  });
}

init().catch((e) => {
  console.error("[sf-web]", e);
  els.error.hidden = false;
  els.error.textContent = String(e && e.message ? e.message : e);
});
