/**
 * Sketchfab Downloader — website server.
 *
 * Zero-dependency Node server (node:http + global fetch):
 *   GET /              → public/ (the web app)
 *   GET /lib/*         → extension/lib/*  (the ORIGINAL pipeline modules, shared)
 *   GET /icons/*       → extension/icons/*
 *   GET /api/health    → { ok, service, version, time }
 *   GET /api/proxy?url → allowlisted, streaming Sketchfab proxy (see server/proxy-policy.mjs)
 *
 * The extension in extension/ is untouched and works independently of this server.
 */
import { createServer } from "node:http";
import { createReadStream } from "node:fs";
import { stat } from "node:fs/promises";
import { extname, join, normalize, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { validateProxyUrl, MAX_PROXY_BYTES, PROXY_TIMEOUT_MS } from "./server/proxy-policy.mjs";

const ROOT = fileURLToPath(new URL(".", import.meta.url));
const PUBLIC_DIR = resolve(ROOT, "public");
const LIB_DIR = resolve(ROOT, "extension", "lib");
const ICONS_DIR = resolve(ROOT, "extension", "icons");
const PORT = process.env.PORT !== undefined && process.env.PORT !== "" ? Number(process.env.PORT) : 3000;
const HOST = "0.0.0.0";
const VERSION = "1.0.0-web";

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".wasm": "application/wasm",
  ".txt": "text/plain; charset=utf-8",
  ".md": "text/markdown; charset=utf-8",
};

function securityHeaders(res, { csp = true } = {}) {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("X-Frame-Options", "DENY");
  if (csp) {
    res.setHeader(
      "Content-Security-Policy",
      [
        "default-src 'self'",
        "script-src 'self' 'wasm-unsafe-eval'",
        "worker-src 'self' blob:",
        "style-src 'self'",
        "img-src 'self' data: blob:",
        "connect-src 'self'",
        "font-src 'self'",
        "object-src 'none'",
        "base-uri 'self'",
        "form-action 'self'",
      ].join("; ")
    );
  }
}

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  securityHeaders(res, { csp: false });
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Content-Length": Buffer.byteLength(body) });
  res.end(body);
}

/** Serve a file from `baseDir`, refusing anything that escapes it. */
async function serveFile(res, baseDir, relPath, { cache = "no-cache" } = {}) {
  const safeRel = normalize(relPath).replace(/^(\.\.[/\\])+/, "");
  const filePath = resolve(baseDir, safeRel);
  if (filePath !== baseDir && !filePath.startsWith(baseDir + sep)) {
    res.writeHead(403); res.end("Forbidden"); return;
  }
  let info;
  try { info = await stat(filePath); } catch { res.writeHead(404); res.end("Not found"); return; }
  if (!info.isFile()) { res.writeHead(404); res.end("Not found"); return; }
  securityHeaders(res);
  res.writeHead(200, {
    "Content-Type": MIME[extname(filePath).toLowerCase()] || "application/octet-stream",
    "Content-Length": info.size,
    "Cache-Control": cache,
  });
  createReadStream(filePath).pipe(res);
}

async function handleProxy(req, res, searchParams) {
  const check = validateProxyUrl(searchParams.get("url") || "");
  if (!check.ok) { sendJson(res, 400, { ok: false, error: check.error }); return; }
  const target = check.url;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), PROXY_TIMEOUT_MS);
  let upstream;
  try {
    upstream = await fetch(target, {
      method: "GET",
      redirect: "follow",
      signal: controller.signal,
      headers: {
        // Browsers forbid page JS from setting these; the public viewer
        // endpoints expect them, so the server sets them itself.
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Referer": "https://sketchfab.com/",
        "Accept": req.headers.accept || "*/*",
      },
    });
  } catch (e) {
    clearTimeout(timer);
    const msg = e && e.name === "AbortError" ? "Upstream request timed out" : `Upstream fetch failed: ${e && e.message ? e.message : e}`;
    sendJson(res, 502, { ok: false, error: msg });
    return;
  }

  // A redirect must not become an SSRF hop to a non-allowlisted host.
  try {
    const finalCheck = validateProxyUrl(upstream.url || target.href);
    if (!finalCheck.ok) {
      clearTimeout(timer);
      sendJson(res, 502, { ok: false, error: "Upstream redirected to a disallowed destination" });
      return;
    }
  } catch { /* upstream.url unparsable — treat as failure below via body read */ }

  const declared = Number(upstream.headers.get("content-length") || 0);
  if (declared && declared > MAX_PROXY_BYTES) {
    clearTimeout(timer);
    sendJson(res, 413, { ok: false, error: "Upstream response too large" });
    return;
  }

  securityHeaders(res, { csp: false });
  const headers = { "Cache-Control": "private, max-age=300" };
  const ct = upstream.headers.get("content-type");
  if (ct) headers["Content-Type"] = ct;
  if (declared) headers["Content-Length"] = declared;
  res.writeHead(upstream.status, headers);

  if (!upstream.body) { clearTimeout(timer); res.end(); return; }
  const reader = upstream.body.getReader();
  let sent = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      sent += value.byteLength;
      if (sent > MAX_PROXY_BYTES) {
        controller.abort();
        res.destroy(new Error("Upstream response too large"));
        return;
      }
      if (!res.write(value)) await new Promise((r) => res.once("drain", r));
    }
    res.end();
  } catch (e) {
    res.destroy(e instanceof Error ? e : new Error(String(e)));
  } finally {
    clearTimeout(timer);
  }
}

const server = createServer(async (req, res) => {
  try {
    const u = new URL(req.url || "/", `http://${req.headers.host || "localhost"}`);
    const path = decodeURIComponent(u.pathname);

    if (req.method !== "GET" && req.method !== "HEAD") {
      sendJson(res, 405, { ok: false, error: "Method not allowed" });
      return;
    }
    if (path === "/api/health") {
      sendJson(res, 200, { ok: true, service: "sketchfab-downloader-web", version: VERSION, time: new Date().toISOString() });
      return;
    }
    if (path === "/api/proxy") { await handleProxy(req, res, u.searchParams); return; }
    if (path.startsWith("/api/")) { sendJson(res, 404, { ok: false, error: "Unknown API route" }); return; }

    if (path === "/favicon.ico") { await serveFile(res, ICONS_DIR, "icon48.png", { cache: "public, max-age=86400" }); return; }
    if (path.startsWith("/lib/")) { await serveFile(res, LIB_DIR, path.slice("/lib/".length), { cache: "public, max-age=3600" }); return; }
    if (path.startsWith("/icons/")) { await serveFile(res, ICONS_DIR, path.slice("/icons/".length), { cache: "public, max-age=86400" }); return; }

    const rel = path === "/" ? "index.html" : path.replace(/^\/+/, "");
    await serveFile(res, PUBLIC_DIR, rel);
  } catch (e) {
    if (!res.headersSent) sendJson(res, 500, { ok: false, error: "Internal server error" });
    else res.destroy(e instanceof Error ? e : undefined);
    console.error("[server]", e);
  }
});

server.listen(PORT, HOST, () => {
  console.log(`Sketchfab Downloader web listening on http://${HOST}:${PORT}`);
});

export { server };
