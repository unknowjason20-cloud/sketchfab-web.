# Phase 1 — Complete Project Audit

Audited: 2026-11-18 · Source zip: `sketchfab-downloader-extension-main.zip` (69 files, ~992 KB)
Baseline tests: **`npm test` → 204 pass / 0 fail** (Node test runner, `extension/test/*.test.js`)

## Architecture of the original project

Manifest V3 Chrome extension. No build step, no runtime dependencies, ES modules throughout.

```
background.js        Service worker (253 LOC) — relays panel <-> offscreen, keep-alive,
                     chrome.downloads save, openBulkPage, dev-mode messages
manifest.json        MV3, permissions: downloads, storage, activeTab, tabs, offscreen
                     host_permissions: sketchfab.com, media/static.sketchfab.com
popup/               Extension popup UI (popup.html 572 LOC inline CSS, popup.js 535 LOC)
content/             panel.js (1376 LOC floating page panel), panel.css, viewer-inject.js
                     (731, MAIN world), webgl-hook.js (781, WebGL texture captures),
                     boot-hook.js (10)
bulk/                Bulk page: bulk.html / bulk.js (172) / bulk.css — one URL per line,
                     sequential queue, stop-after-current, per-row status
offscreen/           offscreen.html + offscreen.js (115) — runs the heavy pipeline in a
                     real DOM page because the service worker OOMs on 4K packs
lib/                 The reusable core (see below)
lib/wasm/            decrypt.wasm — WASM .binz decryptor
_locales/            en / ru / zh_CN — only appName/appDescription (UI strings live in lib/i18n.js)
icons/               16 / 48 / 128
test/                24 test files, 204 tests, all passing at baseline
LICENSE              GPL-3.0 (Copyright (C) 2026 seryi882)
```

## lib/ — the processing pipeline (all preserved unmodified)

| Module | LOC | Role |
|---|---|---|
| `pipeline.js` | 499 | `downloadModel(url, onProgress, options)` — full pipeline: UID → viewer info → static key → WASM decrypt .binz → animations → textures (+ORM pack) → osgjs→glTF → ZIP (full / GLB-only, README.txt, info.json, download-log.txt, MISSING_BLIT.txt) |
| `sf-api.js` | 1093 | `extractUid`, `fetchViewerInfo` (embed HTML prefetched data), `parseViewerMaterials`, `isBinzFormat`, `modelBinzUrls`, `animationUrls`/`fetchAnimations`, `getDiterB`, `extractStaticKey` (live JS, chrome.storage cache), `pickBestImage`/`isDescramblable`, `fetchTextures` (concurrency 3, pk descramble), `mergeCapturedTextures`, `viewerOrientation`, `sanitizeName` |
| `osgjs2gltf.js` | 3180 | osgjs → glTF/GLB converter: materials/PBR, ORM, skins, morphs, animations, samplers, UV sets/transforms, point clouds, lines, transmission/clearcoat/sheen |
| `osg-scene.js` / `osg-codec.js` | 209 / 164 | Scene graph, axis conversion, binary codec used by converter + skin |
| `decrypt.js` | 216 | WASM .binz decrypt (`decryptBinzBytes`, `loadWasmBytes` via `chrome.runtime.getURL`), `DEFAULT_STATIC_KEY`, `outNameFor` |
| `descramble.js` | 568 | Texture descramble (`descrambleImageBytes`, `descrambleRgba`, `offsetFromPk`) — uses createImageBitmap + OffscreenCanvas |
| `skin.js` | 462 | Skeleton / skinning / animation channel decoding |
| `orm.js` | 229 | Metal/rough → packed ORM texture (`planOrm`, `packOrmTexture`) — OffscreenCanvas |
| `zip.js` | 138 | ZIP writer: CRC32, deflate-raw via CompressionStream (Node zlib fallback), STORE fallback |
| `settings.js` | 146 | `sf_prefs` blob: textures, theme, lang (en/ru/zh), devMode, packMode (full/glb), maxTextureEdge (0/2048/4096). Theme/lang/pack/edge immediate; textures/devMode only via Apply. `loadPrefs/savePrefs/normalizePrefs/jobFlagsFromPrefs` |
| `i18n.js` | 422 | Full EN/RU/ZH UI string tables + `t()`, lang switch widgets |
| `devlog.js` | 114 | Session log (400 lines), dev-mode flag, last-run log persistence |
| `run-download.js` | 191 | UI → service-worker port client (`downloadModelInBackground`, `sf-pipeline` port) |
| `save.js` / `save-sw.js` | 52 / 66 | ZIP save: chrome.downloads if present, else `<a download>` blob fallback |
| `ui-settings.js` | 90 | `isJobDirty` (textures/dev only), `formatJobStatus`, pill switches |
| `ui-progress.js` | 45 | `progressFromMessage` — maps real pipeline log lines to 0–100 %, `saveTextFile` |

## Downloading pipeline (original)

1. `extractUid` from a `sketchfab.com/3d-models/…-<32hex>` / `models/<32hex>` URL or a bare UID.
2. Fetch `https://sketchfab.com/models/<uid>/embed`, parse `js-dom-data-prefetched-data` JSON.
3. Reject non-`.binz` (private / old-format) models.
4. Extract the current static decrypt key from live Sketchfab viewer JS (cached in storage, fallback `DEFAULT_STATIC_KEY`).
5. Load `decrypt.wasm`; download `file.binz`, `model_file.binz`, `model_file_wireframe.binz`; decrypt each.
6. Fetch animation clips (`animations/<uid>.bin.gz`, gunzip if still gzipped).
7. If textures enabled: textures API (`/i/models/<uid>/textures?optimized=1`), pick variant by
   Original/≤2K/≤4K, descramble `pk` maps, merge any WebGL captures, pack ORM maps.
8. Convert osgjs → GLB (+ external `model.gltf`/`model.bin`), honoring viewer orientation.
9. Pack ZIP per archive setting; save via chrome.downloads (service worker) .

## Chrome-API surface (what the website must adapt)

| API | Used in | Web equivalent (implemented, see ARCHITECTURE.md) |
|---|---|---|
| `chrome.storage.local/session` | settings, i18n, devlog, sf-api (key cache) | localStorage / sessionStorage adapter (`chrome-shim.js`); in-worker: in-memory adapter |
| `chrome.i18n.getUILanguage` | settings, i18n | `navigator.language` |
| `chrome.runtime.getURL` | decrypt (wasm), panel, popup | Origin-relative URL resolver (`/lib/…` is served from `extension/lib/`) |
| `chrome.runtime.connect/sendMessage/onMessage` | run-download, background, offscreen, panel, popup | Web Worker + postMessage (`web-download.js` + `download-worker.js`), main-thread fallback |
| `chrome.offscreen.createDocument` | background | The Web Worker itself (heavy decrypt/descramble/zip off the UI thread) |
| `chrome.downloads.download` | save, save-sw, background | Blob + `<a download>` — the fallback `save.js` already shipped; shim deliberately does **not** define `chrome.downloads` so that path is taken |
| `chrome.tabs.*` | popup, background (openBulkPage) | Normal in-page navigation / view switching in the SPA |
| Host permissions (CORS bypass) | manifest | Allowlisted server proxy `/api/proxy` (sketchfab hosts only, SSRF-guarded) — a plain website origin gets no CORS grant from sketchfab.com for the embed/textures endpoints |
| Content scripts / WebGL hook | content/* | **Not portable to a website** (it must run inside sketchfab.com's page). Website runs without viewer captures; the pipeline already handles that case explicitly ("No viewer-blit captures") and relies on pk-descramble, which is preserved. The extension keeps the hook. |

## Settings & semantics preserved

Defaults: textures **off**, theme light, lang = browser (en/ru/zh), devMode off, packMode `full`,
maxTextureEdge `0` (Original). Textures/devMode are *job flags* — they take effect only on
**Apply settings**; theme/lang/pack/edge apply immediately. ZIP naming:
`<Name>-<uid8>.zip` or `<Name>-<uid8>-textures.zip`.

## Tests at baseline

24 files in `extension/test/` — animations, axis, base-color workflow, coat/sheen, descramble,
glass geometry, i18n, image MIME, line geometry, materials, morph, object animation, ORM,
orientation, placement, point cloud, samplers, settings, skin, skin weights, textures,
UV sets, UV transforms, zip. **204/204 passing before any change, and after restructuring.**
