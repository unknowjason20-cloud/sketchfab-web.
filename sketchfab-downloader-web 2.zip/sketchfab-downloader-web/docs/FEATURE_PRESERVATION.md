# Feature Preservation Checklist

Every original feature, and where it lives in the website. Status verified by the test
suites (`npm test` = extension tests + web tests) and by the build check (`npm run build`).

## Core pipeline — preserved unmodified in `extension/lib/`
- [x] Public model URL parsing / UID extraction (`extractUid`) — website + bulk both use it
- [x] Invalid-URL detection with a clear error (no UID → job fails before any fetch)
- [x] Public viewer info retrieval (`fetchViewerInfo`, embed prefetched data)
- [x] Private / non-binz model rejection with the original error message
- [x] Static decrypt-key auto-extraction from live viewer JS (+ storage cache + default fallback)
- [x] WASM `.binz` decryption (`file`, `model_file`, `model_file_wireframe`)
- [x] Animation clip download + gunzip
- [x] osgjs → glTF conversion (materials, skins, morphs, animations, ORM, transmission, clearcoat, sheen, point clouds, lines, UV sets/transforms, samplers)
- [x] GLB generation + external `model.gltf` / `model.bin`
- [x] ZIP generation (deflate when smaller, STORE fallback, original `buildZip`)
- [x] Real downloadable output — Blob save via the original `save.js` anchor fallback

## Texture settings — preserved
- [x] Download textures on/off (job flag, Apply-gated)
- [x] Mesh-only downloading (textures off = original behaviour)
- [x] Original size / Maximum 2K / Maximum 4K (`maxTextureEdge` 0 / 2048 / 4096, `pickBestImage`)
- [x] pk descramble algorithm unmodified; ORM packing unmodified

## Archive settings — preserved
- [x] Full archive and GLB-only archive (`packMode`)
- [x] ~~`README.txt`, `info.json`~~ — **removed 2026-11-18 at the owner's request** ("function only"): the ZIP now packs only the .glb, external model.gltf/.bin and their textures, plus `download-log.txt` in dev mode. Raw decrypted files are packed only as a fallback if GLB conversion fails.
- [x] `download-log.txt` inside the ZIP in developer mode
- [x] Undecodable maps are now only noted in the log (the `MISSING_BLIT.txt` file was removed with the same trim)
- [x] Original ZIP naming (`-textures` suffix when textures are on)

## Bulk downloader — preserved (`public/js/app.js`, Bulk view)
- [x] Multiple URLs, one per line, bare UIDs accepted, duplicates de-duplicated (`parseLinks`, same logic as `bulk/bulk.js`)
- [x] Per-item validation, individual progress (live pipeline line per row), overall progress summary
- [x] Success / failure tracking, final OK/failed summary
- [x] Stop-after-current (original semantics)
- [x] Retry — failed rows get a Retry button; "Retry failed" re-runs only failed items
- [x] Each successful model is saved as its own ZIP, exactly like the original bulk page

## Settings panel — preserved
- [x] Theme (light/dark, immediate), Language EN/RU/ZH (immediate, original `lib/i18n.js` strings)
- [x] Archive type, Texture size (immediate), Download textures + Developer mode (Apply-gated, original `isJobDirty` dirty detection and job-status line)
- [x] Apply settings button with saved/dirty flash (original `paintSettingsFlash`)
- [x] Persistence across reloads (chrome.storage adapter → localStorage)

## Developer mode — preserved
- [x] Detailed processing logs in the UI (live log pane)
- [x] Error information + stack in the log on failure
- [x] `download-log.txt` generation (in-ZIP, by pipeline; plus Save log / Copy log for the UI log, original `ui-progress.js` helpers)
- [x] Processing status / real progress bar (`progressFromMessage`, driven by actual pipeline lines — never simulated)

## Extension — preserved
- [x] The complete original extension lives untouched in `extension/` and loads unpacked exactly as before (manifest, popup, panel, bulk page, offscreen, content scripts, WebGL capture hook)
- [x] All 204 original tests still pass against `extension/`

## Known, honestly-stated website limitations
1. **WebGL viewer captures** (`content/webgl-hook.js`) cannot run on a website — they require a
   content script inside sketchfab.com. The website therefore downloads without captures;
   protected maps are recovered by the preserved pk-descramble path. Models whose maps have
   no usable pk variant may keep CDN (striped) maps, noted in the download log —
   the same fallback the extension documents for the no-capture case.
2. **CORS**: sketchfab.com does not CORS-enable its embed/textures endpoints for arbitrary
   origins, so the website routes Sketchfab requests through its own allowlisted proxy
   (`/api/proxy`). No cookies or credentials are ever forwarded; only public URLs are fetched.
3. **Private / download-restricted models** are not bypassed — the original pipeline's own
   checks reject them, on the website exactly as in the extension.
