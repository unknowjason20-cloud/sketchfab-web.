# Test Results — verified 2026-11-18

## Automated suites (`npm test`)

| Suite | Result |
|---|---|
| Original extension tests (`extension/test/*.test.js`, 24 files) — baseline, before any change | **204 pass / 0 fail** |
| Original extension tests — after restructuring into `extension/` | **204 pass / 0 fail** |
| New website tests (`test-web/*.test.js`, 16 tests) | **16 pass / 0 fail** |
| **Total (`npm test`)** | **220 pass / 0 fail** |

New website tests cover: proxy allowlist + SSRF rejections (non-Sketchfab hosts,
look-alike hosts, http, embedded credentials, IP literals, localhost, cloud metadata IP),
proxy size cap, chrome-shim storage contract, Web-Storage JSON round-trip, the *original*
`settings.js` running unchanged on the shim (persistence, language detection, job-flag /
Apply semantics), fetch-wrapper proxy routing, original `extractUid` URL validation,
live-server routes (health, home page UI hooks, `/lib` pipeline + WASM serving,
proxy validation failures, path-traversal refusal, 404/405 handling).

## Production build (`npm run build`)

Build check OK — 29 required files present, all website/server JS parses,
extension manifest verified MV3.

## Live server smoke test (local, `PORT=3100`)

All routes returned 200 with correct content types: `/`, CSS, all JS modules,
`/lib/pipeline.js`, `/lib/settings.js`, `/lib/i18n.js`, `/lib/wasm/decrypt.wasm`
(`application/wasm`), `/icons/icon128.png`, `/api/health` → `{"ok":true,…}`.
Proxy against real Sketchfab: `sketchfab.com/robots.txt` → 200 via proxy;
embed for a non-existent UID → upstream 404 passed through correctly.

## End-to-end real download (the decisive test)

The **unmodified original pipeline**, with all Sketchfab traffic routed through the
website's real `/api/proxy` (the same path the browser takes), downloaded a real
public model — *Xmassash* by Most Popular 3D, UID `651f870ba84e4c2a9da6654c2915909d`:

Mesh-only run (dev mode on, Full archive):
- Viewer info read, 2 materials parsed
- Static key auto-extracted from live viewer JS (`b09706f1…`, 40 hex)
- WASM loaded (253,767 B); `file.binz`, `model_file.binz`, `model_file_wireframe.binz` decrypted
- **GLB ready: 137,428 B, 2 meshes**
- **ZIP ready: `Xmassash-651f870b.zip`, 177,387 B, 9 entries, PK signature, `download-log.txt` included**

Textures-on run (same model):
- Textures API (optimized): 2 maps; both pk-descrambled (512×512 and 512×256)
- **GLB ready: 411,284 B, 2 meshes, 2 images embedded**
- **ZIP ready: `Xmassash-651f870b-textures.zip`, 826,687 B, 12 entries**

## Render startup

`npm start` binds `0.0.0.0:$PORT` (verified locally with `PORT=3100`; code reads
`process.env.PORT` with no localhost-only URLs anywhere in the codebase).
Health-check path for Render: `/api/health`.

## Cloudflare version (added 2026-11-18, same day)

- New tests: 5 Worker tests (health/runtime, static assets + headers, proxy
  allow/deny, method/route guards) — **total suite now 225/225 pass**
  (204 original + 21 website/Worker).
- `npm run build:cloudflare` assembles `dist/` (public + shared lib + icons),
  11 key files verified.
- Worker exercised end-to-end in Node with a filesystem-backed ASSETS mock:
  `/api/health` 200, home page and `/lib/pipeline.js` served from dist,
  real `sketchfab.com/robots.txt` proxied 200, `example.com` blocked 400.
- `npx wrangler deploy --dry-run` (real Wrangler 4.164.0): **passes** —
  33 asset files read, Worker upload 5.79 KiB / gzip 2.25 KiB (free limit
  3 MB), `env.ASSETS` binding recognised. The zip-repo command variant
  (`--config sketchfab-downloader-web/wrangler.toml`) was dry-run verified too.
- Actual deployment to a Cloudflare account was **not** performed (no account
  connected); that step is the user's, using docs/CLOUDFLARE.md.

## Not claimed

- In-browser Worker execution was not run inside a real browser in this environment
  (no browser binary on the build machine). The worker runs the identical pipeline
  module-for-module that the Node end-to-end test exercised, and `web-download.js`
  falls back to running the same pipeline on the main thread if a worker cannot start.
- Responsive layouts are implemented with standard responsive CSS (grid collapse,
  stacked URL row, wrapping header at ≤820 px) and were code-reviewed, not
  screenshot-tested.

## Output trim (2026-11-18, owner-requested)

ZIP contents reduced to functional files only. Full suite still **225/225 pass**.
Real downloads re-verified end-to-end (same Xmassash model, through the proxy):

| Mode | Before | After |
|---|---|---|
| Mesh-only, Full | 177,387 B, 9 entries (glb, gltf, bin, osgjs, 2 raw bins, README, info, log) | **130,457 B, exactly 3 entries: `Xmassash.glb`, `model.gltf`, `model.bin`** |
| Textures on, Full | 826,687 B, 12 entries | **664,834 B, exactly 5 entries: glb, gltf, bin, 2 texture files the gltf uses** |
| GLB only | glb + README + info | **65,240 B, exactly 1 entry: `Xmassash.glb`** |
