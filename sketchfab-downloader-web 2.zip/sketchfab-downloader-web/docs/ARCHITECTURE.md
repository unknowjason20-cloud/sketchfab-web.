# Website Architecture

```
Browser (website origin)                         Render (Node, zero dependencies)
┌──────────────────────────────────────────┐    ┌────────────────────────────────┐
│ public/index.html  SPA: Home / Download  │    │ server.js (node:http)          │
│   Bulk / Settings / Developer log        │───▶│  /            → public/        │
│ public/js/app.js                         │    │  /lib/*       → extension/lib/ │  shared code, served read-only
│   imports the ORIGINAL lib modules:      │    │  /icons/*     → extension/icons│
│   settings, i18n, ui-settings,           │    │  /api/health  → JSON           │
│   ui-progress, sf-api (extractUid),      │    │  /api/proxy?url=… → allowlisted│
│   save                                     │    │    streaming proxy, sketchfab  │
│ public/js/chrome-shim.js                 │    │    hosts only, size-capped     │
│   chrome.storage / i18n / runtime.getURL │    └────────────────────────────────┘
│   + fetch() rewrite → /api/proxy         │
│ public/js/web-download.js                │
│   run-download-compatible client:        │
│   spawns module Web Worker, falls back   │
│   to main-thread pipeline                │
│ public/js/download-worker.js             │
│   (= the web equivalent of offscreen/)   │
│   installs its own chrome shim, imports  │
│   /lib/pipeline.js UNMODIFIED, posts     │
│   progress / done(zip transfer) / error  │
└──────────────────────────────────────────┘
extension/  — the original MV3 extension, untouched, independently loadable.
```

## Why this shape

* **No algorithm is rewritten.** The website imports the exact modules in `extension/lib/`.
  The server serves that directory at `/lib/`, so there is one copy of the pipeline, shared
  by the extension and the website — no fork to drift.
* **Chrome-API adaptation is a shim, not an edit.** `chrome-shim.js` installs a faithful
  `globalThis.chrome` (storage over Web Storage, `i18n.getUILanguage` from the browser,
  `runtime.getURL` as an origin-relative resolver) *before* any lib module is imported.
  Every lib module already wraps its chrome calls in try/catch, and `save.js` already
  falls back to an anchor download when `chrome.downloads` is absent — the shim
  deliberately leaves `downloads`/`tabs`/`offscreen` undefined so those original
  fallback paths are the ones that run.
* **Offscreen → Worker.** The extension used an offscreen document because the service
  worker OOMs on 4K texture packs. The website uses a module Web Worker for the same
  reason (UI stays responsive; OffscreenCanvas/DecompressionStream are available there).
  If a browser cannot start the worker, `web-download.js` runs the same pipeline on the
  main thread — same result, less isolation. Progress, done and error messages mirror
  the original `sf-pipeline` port protocol (`progress` / `done` / `error`).
* **The proxy is the host-permissions replacement, and it is not open.**
  `server/proxy-policy.mjs` allows only `https:` URLs whose hostname is `sketchfab.com`
  or a subdomain of it, rejects credentials-in-URL, IP-literal and localhost hosts,
  caps responses (250 MB) and time (120 s), forwards no cookies, and sets its own
  User-Agent/Referer server-side (browsers forbid those headers from page JS).
  The page-side fetch wrapper only rewrites sketchfab URLs; everything else is untouched.
* **Settings cross the worker boundary as job flags**, exactly as the original passed
  them popup → background → offscreen: `downloadTextures`, `devMode`, `packMode`,
  `maxTextureEdge` are read from the (shimmed) original settings store in `app.js`
  and sent with each job, so the worker never needs localStorage.
* **Zero npm dependencies.** The server is `node:http` + global `fetch`. Render deploys
  are fast, there is no supply-chain surface, and `npm install` is a no-op.

## Data flow for one download

1. User pastes a public model URL → `extractUid` (original) validates it locally.
2. `app.js` reads applied prefs via original `loadPrefs()` and calls
   `downloadModelInWeb(url, onProgress, { devMode, downloadTextures, packMode, maxTextureEdge })`.
3. Worker installs its shim (in-memory storage; static-key cache is per-job there, so the
   key is re-extracted from live JS — the original auto-update behaviour) and imports `/lib/pipeline.js`.
4. All Sketchfab fetches are rewritten to `/api/proxy`, validated again server-side.
5. Pipeline returns `{ zip, zipName, name, author, fileCount, hasGlb }`; the ZIP bytes are
   transferred back and saved with original `save.js`. Progress lines drive the real
   progress bar via original `progressFromMessage`.
