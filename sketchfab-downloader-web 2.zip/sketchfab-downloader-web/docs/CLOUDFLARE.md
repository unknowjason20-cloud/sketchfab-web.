# Cloudflare Deployment — the version that never sleeps

Render's Free web services spin down after 15 minutes idle and share 750 free
instance-hours/month. Cloudflare Workers are serverless: **there is no instance,
so there is nothing to sleep.** Free plan: 100,000 Worker requests/day, static
asset requests free and unlimited, no credit card.

This fits the app perfectly: the server only serves static files and streams a
proxy — the heavy pipeline (decrypt, descramble, GLB conversion) runs in the
visitor's browser, so Worker CPU per request stays tiny (network wait does not
count as CPU time).

## What was added (Render version untouched)

| File | Role |
|---|---|
| `cloudflare/worker.js` | Same routes as `server.js`: `/api/health`, `/api/proxy` (same shared SSRF policy in `server/proxy-policy.mjs`, streamed through a byte-counting transform — never buffered), static assets with the same security/CSP headers |
| `scripts/build-cloudflare.mjs` | `npm run build:cloudflare` — assembles `dist/` = `public/` + `/lib` (extension/lib) + `/icons` |
| `wrangler.toml` | Worker name `sketchfab-downloader-web`, `main = cloudflare/worker.js`, `[assets] directory = ./dist, binding = ASSETS` |
| `test-web/cloudflare-worker.test.js` | Worker unit tests (health, assets, proxy allow/deny, methods) |

Verified: `wrangler deploy --dry-run` passes — 33 asset files, Worker upload
5.79 KiB (gzip 2.25 KiB, far under the 3 MB free limit), ASSETS binding found.
Full suite after adding Cloudflare: **225/225 tests pass.**

## Deploy — Option A: Cloudflare dashboard (GitHub, no terminal)

1. Push this repo to GitHub (contents at repo root — see the zip note below).
2. Cloudflare dashboard → **Workers & Pages → Create → Workers → Connect to Git** → pick the repo.
3. Set exactly:
   - **Build command:** `npm run build:cloudflare`
   - **Deploy command:** `npx wrangler deploy`
   - **Root directory:** blank (if `wrangler.toml` is at the repo root)
4. Deploy. Your URL: `https://sketchfab-downloader-web.<your-subdomain>.workers.dev`
   Health check: open `<url>/api/health` → `{"ok":true,"runtime":"cloudflare-workers",…}`

## Deploy — Option B: from your own PC (terminal)

```bash
npm run build:cloudflare
npx wrangler login
npx wrangler deploy
# or in one go:
npm run deploy:cloudflare
```

## If your GitHub repo contains only the ZIP (like the Render trick)

Cloudflare's build also runs in a shell, so the unzip can happen there too —
these exact commands were verified locally with `wrangler deploy --dry-run`
(wrangler resolves `main` and the assets directory relative to the
`wrangler.toml` location given by `--config`):

- **Build command:** `unzip -o sketchfab-downloader-web.zip && npm --prefix sketchfab-downloader-web run build:cloudflare`
- **Deploy command:** `npx wrangler deploy --config sketchfab-downloader-web/wrangler.toml`
- **Root directory:** blank

## Limits to know (Free plan)

- 100,000 Worker requests/day — page loads of static assets do **not** count
  against this the way API calls do; `/api/proxy` calls do. A model download
  makes roughly 10–60 proxy requests, so the free quota covers on the order of
  thousands of model downloads per day.
- 10 ms CPU per request — the proxy streams and does not parse bodies, so it
  stays well under; the browser does the heavy work.
- No environment variables or secrets are required.
