/**
 * Sketchfab Downloader — Cloudflare Worker (the never-sleeping deployment).
 *
 * The Render/Node server (server.js) and this Worker do exactly the same job:
 *   GET /api/health       → JSON health check
 *   GET /api/proxy?url=…  → allowlisted, streaming Sketchfab proxy
 *   everything else       → static assets (the website + the shared original
 *                           pipeline in /lib, assembled into dist/ at build)
 *
 * Workers are serverless: there is no instance to spin down, no cold-start
 * minute, and static asset requests are free/unlimited on the Free plan.
 * The heavy downloading pipeline never ran on the server anyway — it runs
 * in the visitor's browser (Web Worker) — so a Worker is a natural fit:
 * per-request CPU stays tiny because the proxy only streams bytes through
 * (network wait does not count as CPU time).
 *
 * The SSRF policy is the SAME module the Node server uses:
 * server/proxy-policy.mjs — https only, sketchfab.com hosts only, no
 * credentials, no IP literals, size/time caps enforced while streaming.
 */
import { validateProxyUrl, MAX_PROXY_BYTES } from "../server/proxy-policy.mjs";

const VERSION = "1.0.0-cloudflare";

const CSP = [
  "default-src 'self'",
  "script-src 'self' 'wasm-unsafe-eval'",
  "worker-src 'self' blob:",
  "style-src 'self'",
  "img-src 'self' data: blob:",
  "connect-src 'self'",
  "font-src 'self'",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
].join("; ");

function withHeaders(response, { csp = false } = {}) {
  const res = new Response(response.body, response);
  res.headers.set("X-Content-Type-Options", "nosniff");
  res.headers.set("Referrer-Policy", "no-referrer");
  res.headers.set("X-Frame-Options", "DENY");
  if (csp) res.headers.set("Content-Security-Policy", CSP);
  return res;
}

function json(status, obj) {
  return withHeaders(
    new Response(JSON.stringify(obj), {
      status,
      headers: { "Content-Type": "application/json; charset=utf-8" },
    })
  );
}

async function handleProxy(request, url) {
  const check = validateProxyUrl(url.searchParams.get("url") || "");
  if (!check.ok) return json(400, { ok: false, error: check.error });
  const target = check.url;

  let upstream;
  try {
    upstream = await fetch(target, {
      method: "GET",
      redirect: "follow",
      headers: {
        // Browsers forbid page JS from setting these; the public viewer
        // endpoints expect them, so the Worker sets them itself.
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        Referer: "https://sketchfab.com/",
        Accept: request.headers.get("Accept") || "*/*",
      },
    });
  } catch (e) {
    return json(502, { ok: false, error: `Upstream fetch failed: ${e && e.message ? e.message : e}` });
  }

  // A redirect must not become an SSRF hop to a non-allowlisted host.
  const finalCheck = validateProxyUrl(upstream.url || target.href);
  if (!finalCheck.ok) {
    return json(502, { ok: false, error: "Upstream redirected to a disallowed destination" });
  }

  const declared = Number(upstream.headers.get("content-length") || 0);
  if (declared && declared > MAX_PROXY_BYTES) {
    return json(413, { ok: false, error: "Upstream response too large" });
  }

  const headers = new Headers();
  const ct = upstream.headers.get("content-type");
  if (ct) headers.set("Content-Type", ct);
  if (declared) headers.set("Content-Length", String(declared));
  headers.set("Cache-Control", "private, max-age=300");

  if (!upstream.body) return withHeaders(new Response(null, { status: upstream.status, headers }));
  // Stream through a byte-counting transform so the size cap holds without
  // ever buffering the body in memory (large .binz / texture packs).
  let sent = 0;
  const counter = new TransformStream({
    transform(chunk, controller) {
      sent += chunk.byteLength;
      if (sent > MAX_PROXY_BYTES) {
        controller.error(new Error("Upstream response too large"));
        return;
      }
      controller.enqueue(chunk);
    },
  });
  return withHeaders(
    new Response(upstream.body.pipeThrough(counter), { status: upstream.status, headers })
  );
}

export default {
  /**
   * @param {Request} request
   * @param {{ ASSETS: { fetch: (req: Request) => Promise<Response> } }} env
   */
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;

    if (request.method !== "GET" && request.method !== "HEAD") {
      return json(405, { ok: false, error: "Method not allowed" });
    }
    if (path === "/api/health") {
      return json(200, {
        ok: true,
        service: "sketchfab-downloader-web",
        version: VERSION,
        runtime: "cloudflare-workers",
        time: new Date().toISOString(),
      });
    }
    if (path === "/api/proxy") return handleProxy(request, url);
    if (path.startsWith("/api/")) return json(404, { ok: false, error: "Unknown API route" });

    if (!env || !env.ASSETS) {
      return json(500, { ok: false, error: "Static assets binding (ASSETS) is not configured" });
    }
    const assetRequest = path === "/favicon.ico"
      ? new Request(new URL("/icons/icon48.png", url.origin), request)
      : request;
    const asset = await env.ASSETS.fetch(assetRequest);
    if (asset.status === 404 && !path.includes(".")) {
      // SPA-style fallback for extensionless paths.
      const index = await env.ASSETS.fetch(new Request(new URL("/index.html", url.origin), request));
      return withHeaders(index, { csp: true });
    }
    return withHeaders(asset, { csp: path.endsWith(".html") || path === "/" });
  },
};
