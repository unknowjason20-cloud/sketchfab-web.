import test from "node:test";
import assert from "node:assert/strict";
import { validateProxyUrl, isSketchfabUrl, MAX_PROXY_BYTES } from "../server/proxy-policy.mjs";

test("proxy allows sketchfab.com and its subdomains over https", () => {
  for (const u of [
    "https://sketchfab.com/models/abc/embed",
    "https://www.sketchfab.com/3d-models/x",
    "https://media.sketchfab.com/models/abc/file.binz",
    "https://static.sketchfab.com/builds/app.js",
  ]) {
    assert.equal(validateProxyUrl(u).ok, true, u);
  }
});

test("proxy rejects non-Sketchfab destinations (SSRF guard)", () => {
  for (const u of [
    "https://example.com/file",
    "https://sketchfab.com.evil.com/file",
    "https://evilsketchfab.com/file",
    "https://sketchfab.com@evil.com/file",
  ]) {
    assert.equal(validateProxyUrl(u).ok, false, u);
  }
});

test("proxy rejects http, credentials, IP literals and localhost", () => {
  for (const u of [
    "http://sketchfab.com/models/abc/embed",
    "https://user:pass@sketchfab.com/x",
    "https://127.0.0.1/admin",
    "https://[::1]/admin",
    "https://localhost:3000/admin",
    "https://169.254.169.254/latest/meta-data/",
    "not a url",
    "",
  ]) {
    assert.equal(validateProxyUrl(u).ok, false, u);
  }
});

test("proxy size cap is finite and generous enough for 8K packs", () => {
  assert.ok(MAX_PROXY_BYTES >= 100 * 1024 * 1024);
  assert.ok(MAX_PROXY_BYTES <= 1024 * 1024 * 1024);
});

test("isSketchfabUrl mirrors the allowlist for the page-side fetch wrapper", () => {
  assert.equal(isSketchfabUrl("https://media.sketchfab.com/a.bin"), true);
  assert.equal(isSketchfabUrl("https://example.com/a.bin"), false);
  assert.equal(isSketchfabUrl("data:text/plain,hi"), false);
});
