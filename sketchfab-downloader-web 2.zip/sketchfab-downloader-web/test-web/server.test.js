import test from "node:test";
import assert from "node:assert/strict";
import { once } from "node:events";

// Boot the real server on an ephemeral port and check the routes the
// website depends on. No Sketchfab network access is used: the proxy tests
// only exercise its validation failures, which never reach the network.
process.env.PORT = "0";
const { server } = await import("../server.js");
await once(server, "listening");
const base = `http://127.0.0.1:${server.address().port}`;

test.after(() => server.close());

test("health endpoint reports ok", async () => {
  const r = await fetch(`${base}/api/health`);
  assert.equal(r.status, 200);
  const j = await r.json();
  assert.equal(j.ok, true);
  assert.equal(j.service, "sketchfab-downloader-web");
});

test("home page is served with the downloader UI", async () => {
  const r = await fetch(`${base}/`);
  assert.equal(r.status, 200);
  const html = await r.text();
  assert.match(html, /id="model-url"/);
  assert.match(html, /id="btn-download"/);
  assert.match(html, /id="bulk-links"/);
  assert.match(html, /id="tex-toggle"/);
});

test("original lib modules are served shared at /lib (pipeline + wasm path)", async () => {
  const pipe = await fetch(`${base}/lib/pipeline.js`);
  assert.equal(pipe.status, 200);
  assert.match(await pipe.text(), /downloadModel/);
  const wasm = await fetch(`${base}/lib/wasm/decrypt.wasm`);
  assert.equal(wasm.status, 200);
  assert.equal(wasm.headers.get("content-type"), "application/wasm");
});

test("proxy rejects disallowed destinations before any fetch", async () => {
  for (const bad of [
    "https://example.com/secret",
    "https://169.254.169.254/latest/meta-data/",
    "http://sketchfab.com/x",
  ]) {
    const r = await fetch(`${base}/api/proxy?url=${encodeURIComponent(bad)}`);
    assert.equal(r.status, 400, bad);
    const j = await r.json();
    assert.equal(j.ok, false);
  }
  const missing = await fetch(`${base}/api/proxy`);
  assert.equal(missing.status, 400);
});

test("path traversal outside the static roots is refused", async () => {
  const r = await fetch(`${base}/lib/..%2f..%2fserver.js`);
  assert.notEqual(r.status, 200);
  const r2 = await fetch(`${base}/..%2fserver.js`);
  assert.notEqual(r2.status, 200);
});

test("unknown API routes 404 as JSON, POST is rejected", async () => {
  const r = await fetch(`${base}/api/nope`);
  assert.equal(r.status, 404);
  const p = await fetch(`${base}/api/health`, { method: "POST" });
  assert.equal(p.status, 405);
});
