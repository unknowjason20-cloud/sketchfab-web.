import test from "node:test";
import assert from "node:assert/strict";

// The shim is a browser module; its pure factories are importable in Node
// because they never touch window/localStorage until install time, and the
// storage factories take their backing store as an argument.
import { createMemoryStorage, createWebStorage, shouldProxy, proxyUrlFor } from "../public/js/chrome-shim.js";

test("memory storage adapter honours the chrome.storage get/set contract", async () => {
  const s = createMemoryStorage();
  await s.set({ sf_prefs: { theme: "dark" }, sf_lang: "ru" });
  assert.deepEqual(await s.get("sf_lang"), { sf_lang: "ru" });
  assert.deepEqual(await s.get(["sf_prefs", "missing"]), { sf_prefs: { theme: "dark" } });
  assert.deepEqual(await s.get({ missing: "dflt" }), { missing: "dflt" });
  await s.remove("sf_lang");
  assert.deepEqual(await s.get("sf_lang"), {});
});

test("web storage adapter round-trips JSON through a Storage-like backing", async () => {
  const backing = {
    _m: new Map(),
    get length() { return this._m.size; },
    key: (i) => [...this._m.keys()][i] ?? null,
    getItem(k) { return this._m.has(k) ? this._m.get(k) : null; },
    setItem(k, v) { this._m.set(k, String(v)); },
    removeItem(k) { this._m.delete(k); },
    clear() { this._m.clear(); },
  };
  const s = createWebStorage(backing);
  await s.set({ sf_prefs: { textures: true, maxTextureEdge: 2048 } });
  const got = await s.get(["sf_prefs"]);
  assert.deepEqual(got.sf_prefs, { textures: true, maxTextureEdge: 2048 });
  // Persisted as JSON in the backing store, like localStorage would hold it.
  assert.equal(typeof backing.getItem("sf_prefs"), "string");
});

test("original settings module runs unchanged on the shim (persistence + Apply semantics)", async () => {
  // Install a chrome global backed by memory storage, then import the
  // UNMODIFIED extension settings module and exercise it.
  const local = createMemoryStorage();
  const session = createMemoryStorage();
  globalThis.chrome = {
    storage: { local, session },
    i18n: { getUILanguage: () => "ru-RU" },
    runtime: { getURL: (p) => "/" + p, lastError: null },
  };
  const settings = await import("../extension/lib/settings.js?shim-test");
  const def = await settings.loadPrefs();
  assert.equal(def.lang, "ru"); // detected from the shimmed UI language
  const saved = await settings.savePrefs({ textures: true, packMode: "glb", maxTextureEdge: 4096 });
  assert.equal(saved.textures, true);
  const reloaded = await settings.loadPrefs();
  assert.deepEqual(reloaded, saved);
  assert.deepEqual(settings.jobFlagsFromPrefs(reloaded), {
    downloadTextures: true, devMode: false, packMode: "glb", maxTextureEdge: 4096,
  });
  delete globalThis.chrome;
});

test("fetch wrapper only proxies Sketchfab hosts, never same-origin or other sites", () => {
  const base = "https://downloader.example/index.html";
  assert.equal(shouldProxy("https://sketchfab.com/models/x/embed", base), true);
  assert.equal(shouldProxy("https://media.sketchfab.com/a.binz", base), true);
  assert.equal(shouldProxy("https://example.com/a", base), false);
  assert.equal(shouldProxy("https://sketchfab.com.evil.com/a", base), false);
  assert.equal(proxyUrlFor("https://sketchfab.com/models/x/embed", base),
    "/api/proxy?url=" + encodeURIComponent("https://sketchfab.com/models/x/embed"));
});

test("original extractUid validates website input exactly like the extension", async () => {
  const { extractUid } = await import("../extension/lib/sf-api.js");
  assert.equal(
    extractUid("https://sketchfab.com/3d-models/foo-a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4"),
    "a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4"
  );
  assert.equal(extractUid("https://example.com/not-a-model"), null);
  assert.equal(extractUid(""), null);
});
