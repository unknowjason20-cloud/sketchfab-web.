import test from "node:test";
import assert from "node:assert/strict";
import worker from "../cloudflare/worker.js";

// Mock the Workers Static Assets binding with an in-memory site.
function makeEnv() {
  const files = new Map([
    ["/index.html", "<html>downloader</html>"],
    ["/lib/pipeline.js", "export async function downloadModel(){}"],
    ["/icons/icon48.png", "PNG"],
  ]);
  return {
    ASSETS: {
      async fetch(req) {
        const path = new URL(req.url).pathname;
        if (files.has(path)) return new Response(files.get(path), { status: 200 });
        return new Response("not found", { status: 404 });
      },
    },
  };
}
const call = (path, opts) => worker.fetch(new Request(`https://site.example${path}`, opts), makeEnv());

test("worker health endpoint identifies the Cloudflare runtime", async () => {
  const r = await call("/api/health");
  assert.equal(r.status, 200);
  const j = await r.json();
  assert.equal(j.ok, true);
  assert.equal(j.runtime, "cloudflare-workers");
});

test("worker serves static assets with security headers", async () => {
  const r = await call("/");
  // "/" is extensionless → ASSETS 404 → SPA fallback serves /index.html
  assert.equal(r.status, 200);
  assert.match(await r.text(), /downloader/);
  assert.equal(r.headers.get("x-content-type-options"), "nosniff");
  const lib = await call("/lib/pipeline.js");
  assert.equal(lib.status, 200);
  assert.match(await lib.text(), /downloadModel/);
});

test("worker proxy rejects disallowed destinations before any fetch", async () => {
  for (const bad of ["https://example.com/x", "https://169.254.169.254/meta", "http://sketchfab.com/x"]) {
    const r = await call(`/api/proxy?url=${encodeURIComponent(bad)}`);
    assert.equal(r.status, 400, bad);
  }
});

test("worker proxy streams an allowed Sketchfab response through", async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async (input) => {
    const url = typeof input === "string" ? input : (input.href || input.url || String(input));
    assert.match(url, /^https:\/\/sketchfab\.com\//);
    return new Response("EMBED-HTML", {
      status: 200,
      headers: { "Content-Type": "text/html", "Content-Length": "10" },
    });
  };
  try {
    const r = await call(`/api/proxy?url=${encodeURIComponent("https://sketchfab.com/models/abc/embed")}`);
    assert.equal(r.status, 200);
    assert.equal(await r.text(), "EMBED-HTML");
  } finally {
    globalThis.fetch = originalFetch;
  }
});

test("worker rejects non-GET methods and unknown API routes", async () => {
  const p = await call("/api/health", { method: "POST" });
  assert.equal(p.status, 405);
  const u = await call("/api/nope");
  assert.equal(u.status, 404);
});
