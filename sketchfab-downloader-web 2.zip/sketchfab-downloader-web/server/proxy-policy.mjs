/**
 * SSRF policy for the website's Sketchfab proxy.
 *
 * A plain website origin receives no CORS grant from sketchfab.com for the
 * embed / textures endpoints, and browsers cannot set the User-Agent /
 * Referer headers the public viewer data expects. The server therefore
 * fetches public Sketchfab URLs on the page's behalf — but ONLY those URLs.
 * This module is the whole policy, kept pure so it can be unit-tested.
 *
 * Rules:
 *  - https: only
 *  - hostname must be sketchfab.com or a subdomain of it
 *    (media.sketchfab.com, static.sketchfab.com, www.sketchfab.com, …)
 *  - no credentials embedded in the URL
 *  - no IP-literal, localhost, or trailing-dot hostnames
 *  - response size and time are capped by the caller using these constants
 */

export const MAX_PROXY_BYTES = 250 * 1024 * 1024; // largest .binz + 8K texture packs
export const PROXY_TIMEOUT_MS = 120_000;

const ALLOWED_SUFFIX = ".sketchfab.com";
const ALLOWED_EXACT = "sketchfab.com";

function isIpLiteral(host) {
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) return true; // IPv4
  if (host.includes(":") || host.startsWith("[")) return true; // IPv6
  return false;
}

/**
 * @param {string} raw candidate URL from the client
 * @returns {{ ok: true, url: URL } | { ok: false, error: string }}
 */
export function validateProxyUrl(raw) {
  if (typeof raw !== "string" || !raw) {
    return { ok: false, error: "Missing url parameter" };
  }
  let url;
  try {
    url = new URL(raw);
  } catch {
    return { ok: false, error: "Invalid URL" };
  }
  if (url.protocol !== "https:") {
    return { ok: false, error: "Only https:// URLs may be proxied" };
  }
  if (url.username || url.password) {
    return { ok: false, error: "URLs with embedded credentials are not allowed" };
  }
  const host = url.hostname.toLowerCase();
  if (!host || host.endsWith(".")) {
    return { ok: false, error: "Invalid hostname" };
  }
  if (host === "localhost" || isIpLiteral(host)) {
    return { ok: false, error: "IP-literal and localhost destinations are not allowed" };
  }
  if (host !== ALLOWED_EXACT && !host.endsWith(ALLOWED_SUFFIX)) {
    return { ok: false, error: "Only sketchfab.com destinations may be proxied" };
  }
  return { ok: true, url };
}

/** True when a page-side fetch URL should be routed through the proxy. */
export function isSketchfabUrl(raw) {
  try {
    const u = new URL(String(raw), "https://placeholder.invalid");
    if (u.protocol !== "https:" && u.protocol !== "http:") return false;
    const host = u.hostname.toLowerCase();
    return host === ALLOWED_EXACT || host.endsWith(ALLOWED_SUFFIX);
  } catch {
    return false;
  }
}
