/**
 * Web equivalent of the extension's offscreen document.
 *
 * The extension ran the heavy pipeline offscreen because the service worker
 * OOMs on 4K texture packs. Here a module Web Worker plays that role:
 * decrypt / descramble / zip happen off the UI thread, progress is posted
 * back line-by-line, and the finished ZIP is transferred to the page, which
 * saves it with the original lib/save.js.
 *
 * Protocol (mirrors the original sf-pipeline port messages):
 *   in : { action: "download", url, devMode?, downloadTextures?, packMode?, maxTextureEdge? }
 *   out: { type: "progress", text } | { type: "done", zip, zipName, name, author,
 *          hasGlb, fileCount, zipBytes, logText } | { type: "error", error, logText }
 */
import { installChromeShim } from "./chrome-shim.js";

installChromeShim({ inWorker: true });

const logLines = [];

self.addEventListener("message", async (ev) => {
  const msg = ev.data || {};
  if (msg.action !== "download") return;
  logLines.length = 0;
  const step = (text) => {
    const line = String(text || "");
    logLines.push(line);
    self.postMessage({ type: "progress", text: line });
  };
  try {
    // Imported after the shim is installed: lib/decrypt.js resolves the WASM
    // through chrome.runtime.getURL, lib/settings.js reads chrome.storage.
    const { downloadModel } = await import("/lib/pipeline.js");
    const options = {};
    if (msg.downloadTextures === true || msg.downloadTextures === false) options.downloadTextures = msg.downloadTextures;
    if (msg.devMode === true || msg.devMode === false) options.devMode = msg.devMode;
    if (msg.packMode === "glb" || msg.packMode === "full") options.packMode = msg.packMode;
    if (msg.maxTextureEdge === 0 || msg.maxTextureEdge === 2048 || msg.maxTextureEdge === 4096) options.maxTextureEdge = msg.maxTextureEdge;

    const result = await downloadModel(msg.url, step, options);
    const zip = result.zip instanceof Uint8Array ? result.zip : new Uint8Array(result.zip || []);
    if (!zip.length) throw new Error("Pipeline returned empty ZIP");
    self.postMessage(
      {
        type: "done",
        zip,
        zipName: result.zipName,
        name: result.name,
        author: result.author,
        hasGlb: !!result.hasGlb,
        fileCount: result.fileCount || 0,
        zipBytes: zip.length,
        logText: logLines.join("\n"),
      },
      [zip.buffer]
    );
  } catch (e) {
    const message = e && e.message ? e.message : String(e);
    logLines.push(`ERROR: ${message}`);
    self.postMessage({ type: "error", error: message, logText: logLines.join("\n") });
  }
});
