/**
 * Web equivalent of lib/run-download.js.
 *
 * Same job interface the popup / bulk page used against the extension's
 * service-worker port — downloadModelInBackground(url, onProgress, opts) —
 * but the "background" here is a Web Worker running the original pipeline
 * (see download-worker.js). If the worker cannot start (very old browser),
 * the same unmodified pipeline runs on the main thread instead.
 *
 * Resolves with the same shape as the original fallback path:
 * { zip, zipName, name, author, hasGlb, fileCount, zipBytes, logText,
 *   savedByBackground: false }
 * Callers save `zip` with lib/save.js, exactly like the original UI did
 * when the background had not already saved it.
 */

let worker = null;
let workerBroken = false;

function getWorker() {
  if (workerBroken) return null;
  if (worker) return worker;
  try {
    worker = new Worker(new URL("./download-worker.js", import.meta.url), { type: "module" });
  } catch {
    workerBroken = true;
    return null;
  }
  return worker;
}

function jobMessage(url, opts) {
  const msg = { action: "download", url, devMode: !!opts.devMode, capturedTextures: [] };
  if (opts.downloadTextures === true || opts.downloadTextures === false) msg.downloadTextures = opts.downloadTextures;
  if (opts.packMode === "glb" || opts.packMode === "full") msg.packMode = opts.packMode;
  if (opts.maxTextureEdge === 0 || opts.maxTextureEdge === 2048 || opts.maxTextureEdge === 4096) msg.maxTextureEdge = opts.maxTextureEdge;
  return msg;
}

function runInWorker(url, onProgress, opts) {
  return new Promise((resolve, reject) => {
    const w = getWorker();
    if (!w) { reject(new Error("worker-unavailable")); return; }
    let settled = false;
    const cleanup = () => {
      w.removeEventListener("message", onMsg);
      w.removeEventListener("error", onErr);
    };
    const finish = (fn, val) => { if (settled) return; settled = true; cleanup(); fn(val); };
    const onMsg = (ev) => {
      const m = ev.data || {};
      if (m.type === "progress") { try { onProgress(m.text || ""); } catch { /* UI */ } return; }
      if (m.type === "done") {
        const zip = m.zip instanceof Uint8Array ? m.zip : new Uint8Array(m.zip || []);
        finish(resolve, {
          zip, zipName: m.zipName, name: m.name, author: m.author,
          hasGlb: !!m.hasGlb, fileCount: m.fileCount || 0,
          zipBytes: m.zipBytes || zip.length, logText: m.logText || "",
          savedByBackground: false,
        });
        return;
      }
      if (m.type === "error") {
        const err = new Error(m.error || "Download failed");
        err.logText = m.logText || "";
        finish(reject, err);
      }
    };
    const onErr = (e) => {
      // A worker-level failure (e.g. module load) — mark it broken so the
      // caller falls back to the main thread for this and future jobs.
      workerBroken = true;
      try { worker.terminate(); } catch { /* noop */ }
      worker = null;
      const err = new Error("worker-unavailable");
      err.logText = e && e.message ? String(e.message) : "";
      finish(reject, err);
    };
    w.addEventListener("message", onMsg);
    w.addEventListener("error", onErr);
    w.postMessage(jobMessage(url, opts));
  });
}

async function runOnMainThread(url, onProgress, opts) {
  const { downloadModel } = await import("/lib/pipeline.js");
  const logLines = [];
  const step = (line) => { logLines.push(String(line || "")); onProgress(line); };
  const result = await downloadModel(url, step, jobMessage(url, opts));
  const zip = result.zip instanceof Uint8Array ? result.zip : new Uint8Array(result.zip || []);
  if (!zip.length) throw new Error("Pipeline returned empty ZIP");
  return {
    zip, zipName: result.zipName, name: result.name, author: result.author,
    hasGlb: !!result.hasGlb, fileCount: result.fileCount || 0,
    zipBytes: zip.length, logText: logLines.join("\n"), savedByBackground: false,
  };
}

/**
 * @param {string} url public Sketchfab model page URL (or bare UID URL built by caller)
 * @param {(msg: string) => void} [onProgress]
 * @param {{ devMode?: boolean, downloadTextures?: boolean, packMode?: string, maxTextureEdge?: number }} [opts]
 */
export async function downloadModelInWeb(url, onProgress = () => {}, opts = {}) {
  try {
    return await runInWorker(url, onProgress, opts);
  } catch (e) {
    if (e && e.message === "worker-unavailable") {
      onProgress("Worker unavailable — running the pipeline on the main thread…");
      return runOnMainThread(url, onProgress, opts);
    }
    throw e;
  }
}
