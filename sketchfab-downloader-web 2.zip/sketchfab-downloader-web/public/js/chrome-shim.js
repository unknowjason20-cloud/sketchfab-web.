/**
 * Chrome Extension API compatibility layer for the website.
 *
 * The original lib/ modules were written against chrome.* APIs and already
 * defensive-wrap every call. This shim installs faithful web equivalents
 * BEFORE any lib module is imported, so the original code runs unmodified:
 *
 *   chrome.storage.local    → Web Storage (localStorage)   [main thread]
 *                           → in-memory Map                 [worker]
 *   chrome.storage.session  → sessionStorage / in-memory Map
 *   chrome.i18n.getUILanguage() → navigator.language
 *   chrome.runtime.getURL(p)    → origin-relative "/…" URL
 *   chrome.runtime.lastError    → null
 *
 * Deliberately NOT provided: chrome.downloads, chrome.tabs, chrome.offscreen.
 * lib/save.js already falls back to a Blob + <a download> save when
 * chrome.downloads is absent, and that original fallback is what the website
 * uses. Faking the others would change original behaviour instead of adapting it.
 *
 * It also wraps fetch(): requests to sketchfab.com hosts are rewritten to the
 * site's own allowlisted proxy (/api/proxy), because a website origin gets no
 * CORS grant from Sketchfab and cannot set User-Agent/Referer. Every other
 * request passes through untouched.
 */

export function createMemoryStorage() {
  const map = new Map();
  return {
    _map: map,
    async get(keys) {
      if (keys == null) return Object.fromEntries(map);
      if (typeof keys === "string") {
        return map.has(keys) ? { [keys]: map.get(keys) } : {};
      }
      if (Array.isArray(keys)) {
        const out = {};
        for (const k of keys) if (map.has(k)) out[k] = map.get(k);
        return out;
      }
      // Object form: { key: defaultValue }
      const out = {};
      for (const [k, dflt] of Object.entries(keys)) out[k] = map.has(k) ? map.get(k) : dflt;
      return out;
    },
    async set(obj) {
      for (const [k, v] of Object.entries(obj || {})) map.set(k, v);
    },
    async remove(keys) {
      for (const k of Array.isArray(keys) ? keys : [keys]) map.delete(k);
    },
    async clear() { map.clear(); },
  };
}

export function createWebStorage(backing) {
  // backing: a Storage object (localStorage / sessionStorage)
  const mem = createMemoryStorage();
  if (!backing) return mem;
  return {
    async get(keys) {
      const read = (k) => {
        const raw = backing.getItem(k);
        if (raw == null) return undefined;
        try { return JSON.parse(raw); } catch { return raw; }
      };
      if (keys == null) {
        const out = {};
        for (let i = 0; i < backing.length; i++) {
          const k = backing.key(i);
          if (k) out[k] = read(k);
        }
        return out;
      }
      if (typeof keys === "string") {
        const v = read(keys);
        return v === undefined ? {} : { [keys]: v };
      }
      if (Array.isArray(keys)) {
        const out = {};
        for (const k of keys) { const v = read(k); if (v !== undefined) out[k] = v; }
        return out;
      }
      const out = {};
      for (const [k, dflt] of Object.entries(keys)) {
        const v = read(k);
        out[k] = v === undefined ? dflt : v;
      }
      return out;
    },
    async set(obj) {
      for (const [k, v] of Object.entries(obj || {})) {
        try { backing.setItem(k, JSON.stringify(v)); }
        catch { await mem.set({ [k]: v }); } // storage full/blocked → session-only fallback
      }
    },
    async remove(keys) {
      for (const k of Array.isArray(keys) ? keys : [keys]) backing.removeItem(k);
    },
    async clear() { backing.clear(); },
  };
}

const SKETCHFAB_SUFFIX = ".sketchfab.com";

/** Page-side mirror of the server proxy policy (server re-validates). */
export function shouldProxy(rawUrl, baseHref) {
  try {
    const u = new URL(String(rawUrl), baseHref || undefined);
    if (u.protocol !== "https:" && u.protocol !== "http:") return false;
    // Same-origin requests (our own /lib, /api, wasm, …) are never proxied.
    if (typeof location !== "undefined" && u.origin === location.origin) return false;
    const host = u.hostname.toLowerCase();
    return host === "sketchfab.com" || host.endsWith(SKETCHFAB_SUFFIX);
  } catch {
    return false;
  }
}

export function proxyUrlFor(rawUrl, baseHref) {
  const u = new URL(String(rawUrl), baseHref || undefined);
  return `/api/proxy?url=${encodeURIComponent(u.href)}`;
}

/**
 * Install the shim on `globalThis`.
 * @param {{ inWorker?: boolean }} [opts]
 */
export function installChromeShim(opts = {}) {
  const g = globalThis;
  if (g.__sfChromeShimInstalled) return g.chrome;
  g.__sfChromeShimInstalled = true;

  const inWorker = !!opts.inWorker || typeof document === "undefined";
  let localStore, sessionStore;
  if (inWorker) {
    localStore = createMemoryStorage();
    sessionStore = createMemoryStorage();
  } else {
    let ls = null, ss = null;
    try { ls = window.localStorage; } catch { /* blocked */ }
    try { ss = window.sessionStorage; } catch { /* blocked */ }
    localStore = createWebStorage(ls);
    sessionStore = createWebStorage(ss);
  }

  const navLang = (() => {
    try { return (g.navigator && g.navigator.language) || "en"; } catch { return "en"; }
  })();

  g.chrome = {
    storage: {
      local: localStore,
      session: sessionStore,
      onChanged: { addListener() {}, removeListener() {} },
    },
    i18n: { getUILanguage: () => navLang },
    runtime: {
      id: "sketchfab-downloader-web",
      lastError: null,
      getURL: (p) => "/" + String(p || "").replace(/^\/+/, ""),
      getManifest: () => ({ name: "Sketchfab Downloader (Web)", version: "1.0.0-web" }),
    },
    // downloads / tabs / offscreen intentionally absent — see header comment.
  };

  // Route Sketchfab requests through the allowlisted proxy.
  if (typeof g.fetch === "function" && !g.__sfFetchWrapped) {
    g.__sfFetchWrapped = true;
    const originalFetch = g.fetch.bind(g);
    const base = inWorker ? g.location.href : undefined;
    g.fetch = (input, init) => {
      try {
        const raw = typeof input === "string" ? input : input && input.url;
        if (raw && shouldProxy(raw, base)) {
          const proxied = proxyUrlFor(raw, base);
          if (typeof input === "string") return originalFetch(proxied, init);
          return originalFetch(new Request(proxied, input), init);
        }
      } catch { /* fall through to the original request */ }
      return originalFetch(input, init);
    };
  }
  return g.chrome;
}
