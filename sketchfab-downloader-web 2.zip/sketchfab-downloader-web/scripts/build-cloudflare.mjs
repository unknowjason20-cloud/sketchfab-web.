/**
 * Assemble dist/ for the Cloudflare Worker (Workers Static Assets).
 *
 * The website expects three mounts that live in different places in the repo:
 *   /        → public/          (the web app)
 *   /lib/    → extension/lib/   (the ORIGINAL pipeline modules, shared)
 *   /icons/  → extension/icons/
 * Workers Static Assets serves one directory, so this build copies those
 * three trees into dist/ with exactly that layout, then verifies the result.
 * Nothing is modified — dist/ is a straight copy, regenerated on every build.
 */
import { cp, rm, mkdir, access } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { join } from "node:path";

const ROOT = fileURLToPath(new URL("..", import.meta.url));
const DIST = join(ROOT, "dist");

await rm(DIST, { recursive: true, force: true });
await mkdir(DIST, { recursive: true });
await cp(join(ROOT, "public"), DIST, { recursive: true });
await cp(join(ROOT, "extension", "lib"), join(DIST, "lib"), { recursive: true });
await cp(join(ROOT, "extension", "icons"), join(DIST, "icons"), { recursive: true });

const required = [
  "index.html",
  "css/styles.css",
  "js/app.js",
  "js/chrome-shim.js",
  "js/web-download.js",
  "js/download-worker.js",
  "lib/pipeline.js",
  "lib/sf-api.js",
  "lib/settings.js",
  "lib/wasm/decrypt.wasm",
  "icons/icon128.png",
];
let failed = 0;
for (const rel of required) {
  try { await access(join(DIST, rel)); }
  catch { console.error(`MISSING in dist/: ${rel}`); failed++; }
}
if (failed) { console.error(`Cloudflare build FAILED (${failed} missing file(s))`); process.exit(1); }
console.log(`Cloudflare build OK — dist/ assembled (${required.length} key files verified).`);
