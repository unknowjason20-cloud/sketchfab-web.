/**
 * Production build check (there is no bundler — the site is served as-is).
 * Verifies that every file the website and extension need actually exists,
 * that all JavaScript parses, and that the shared pipeline is in place.
 * Exits non-zero on any failure so Render's build step catches a bad deploy.
 */
import { access, readFile } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { join } from "node:path";

const ROOT = fileURLToPath(new URL("..", import.meta.url));
const required = [
  "server.js",
  "server/proxy-policy.mjs",
  "public/index.html",
  "public/css/styles.css",
  "public/js/app.js",
  "public/js/chrome-shim.js",
  "public/js/web-download.js",
  "public/js/download-worker.js",
  "extension/manifest.json",
  "extension/background.js",
  "extension/lib/pipeline.js",
  "extension/lib/run-download.js",
  "extension/lib/osgjs2gltf.js",
  "extension/lib/osg-scene.js",
  "extension/lib/osg-codec.js",
  "extension/lib/decrypt.js",
  "extension/lib/descramble.js",
  "extension/lib/skin.js",
  "extension/lib/zip.js",
  "extension/lib/orm.js",
  "extension/lib/sf-api.js",
  "extension/lib/settings.js",
  "extension/lib/save.js",
  "extension/lib/wasm/decrypt.wasm",
  "extension/popup/popup.html",
  "extension/bulk/bulk.html",
  "extension/offscreen/offscreen.html",
  "LICENSE",
  "render.yaml",
  "wrangler.toml",
  "cloudflare/worker.js",
  "scripts/build-cloudflare.mjs",
];
const jsToCheck = [
  "server.js", "server/proxy-policy.mjs",
  "public/js/app.js", "public/js/chrome-shim.js",
  "public/js/web-download.js", "public/js/download-worker.js",
  "scripts/build-check.mjs", "cloudflare/worker.js", "scripts/build-cloudflare.mjs",
];

let failed = 0;
for (const rel of required) {
  try { await access(join(ROOT, rel)); }
  catch { console.error(`MISSING: ${rel}`); failed++; }
}
for (const rel of jsToCheck) {
  const r = spawnSync(process.execPath, ["--check", join(ROOT, rel)], { encoding: "utf8" });
  if (r.status !== 0) { console.error(`SYNTAX: ${rel}\n${r.stderr}`); failed++; }
}
// The HTML must reference the app entry and the shared-lib mount must be real.
const html = await readFile(join(ROOT, "public/index.html"), "utf8");
if (!html.includes("/js/app.js")) { console.error("index.html does not load /js/app.js"); failed++; }
const manifest = JSON.parse(await readFile(join(ROOT, "extension/manifest.json"), "utf8"));
if (manifest.manifest_version !== 3) { console.error("extension manifest is not MV3"); failed++; }

if (failed) { console.error(`Build check FAILED (${failed} problem(s))`); process.exit(1); }
console.log(`Build check OK — ${required.length} required files present, ${jsToCheck.length} JS files parse, extension manifest MV3.`);
